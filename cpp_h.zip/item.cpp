#include "item.h"
#include "entity.h"

#define LOG(msg) if(log) log->push_back(msg)

bool Item::use(Entity* user, std::vector<std::string>* log, Entity* enemy)
{
    if (!user) return false;

    if (type == ItemType::EQUIPPABLE)
        return false;

    LOG(user->name + " utilise " + name);
    for (Action* a : actions)
    {
        if (!a) continue;
        // selfTarget=TRUE  → s'applique au joueur
        // selfTarget=FALSE → s'applique à l'ennemi si disponible, sinon au joueur
        Entity* cible = a->selfTarget ? user : (enemy ? enemy : user);
        a->apply(cible, log);
    }
    return true;
}

void Item::applyEquipEffects(Entity* target, std::vector<std::string>* log)
{
    if (!target) return;
    LOG(target->name + " equipe " + name);
    for (Action* a : actions) a->apply(target, log);
    equipped = true;
}

void Item::revertEquipEffects(Entity* target, std::vector<std::string>* log)
{
    if (!target || !equipped) return;
    LOG(target->name + " desequipe " + name);
    for (Action* a : actions)
    {
        switch (a->type)
        {
            case ActionType::BUFF_ATK:   target->baseDommage -= a->value; break;
            case ActionType::BUFF_DEF:   target->baseDefense -= a->value; break;
            case ActionType::DEBUFF_ATK: target->baseDommage += a->value; break;
            case ActionType::DEBUFF_DEF: target->baseDefense += a->value; break;
            default: break;
        }
    }
    equipped = false;
}