#pragma once
#include <string>
#include <vector>
#include "action.h"

class Entity;

// ============================================================
//  ENUMS
// ============================================================

enum class ItemType
{
    CONSUMABLE,
    EQUIPPABLE
};

enum class EquipSlot
{
    NONE,       // consommable ou non défini
    HEAD,       // casque
    CHEST,      // armure
    MAIN_HAND,  // arme 1 main (droite en priorité, gauche si droite prise)
    TWO_HANDS,  // arme 2 mains (occupe les deux)
    LEGS,       // pantalon
    FEET,       // bottes
    NECK,       // collier
    RING        // bague (3 slots disponibles)
};

// ============================================================
//  CLASSE ITEM
// ============================================================

class Item
{
public:
    int         id;
    std::string name;
    std::string description;
    int         value;    // valeur en or
    ItemType    type;
    EquipSlot   slotType = EquipSlot::NONE;
    bool        equipped = false;
    int         iconId   = 0;

    std::vector<Action*> actions;

    Item(int id, const std::string& name, const std::string& description,
         int value, ItemType type, std::vector<Action*> actions,
         int iconId = 0, EquipSlot slotType = EquipSlot::NONE)
        : id(id), name(name), description(description),
          value(value), type(type), actions(actions),
          iconId(iconId), slotType(slotType) {}

    // Retourne true si l'item doit être retiré de l'inventaire
    bool use(Entity* user, std::vector<std::string>* log = nullptr, Entity* enemy = nullptr);

    // Applique / annule les effets de l'équipement sur une entité
    void applyEquipEffects(Entity* target, std::vector<std::string>* log = nullptr);
    void revertEquipEffects(Entity* target, std::vector<std::string>* log = nullptr);
};