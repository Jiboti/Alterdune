#pragma once
#include "entity.h"
#include "inventory.h"
#include "item.h"

// ============================================================
//  ENUM
// ============================================================

enum class PowerClass
{
    BERSERKER,
    GUARDIAN,
    TRICKSTER
};

// ============================================================
//  SLOTS D'ÉQUIPEMENT
// ============================================================

struct EquipmentSlots
{
    Item* head   = nullptr;
    Item* chest  = nullptr;
    Item* handR  = nullptr;
    Item* handL  = nullptr;
    Item* legs   = nullptr;
    Item* feet   = nullptr;
    Item* neck   = nullptr;
    Item* ring[3] = {nullptr, nullptr, nullptr};

    int ringCount() const
    {
        int n = 0;
        for (int i = 0; i < 3; i++) if (ring[i]) n++;
        return n;
    }

    int firstFreeRingSlot() const
    {
        for (int i = 0; i < 3; i++) if (!ring[i]) return i;
        return -1;
    }
};

// ============================================================
//  CLASSE PLAYER
// ============================================================

class Player : public Entity
{
public:
    int        level;  // public pour compatibilité — voir aussi getLevel()/setLevel()
    int        xp;
    int        gold;
    PowerClass powerClass;

    std::vector<Action*> powerActions;
    bool                 usePower = true;

    int pendingLevelUps = 0;

    EquipmentSlots equipment;

    static constexpr int MAX_CONSUMABLES = 5;

    // ── Encapsulation : stats de run privées ─────────────────
    // nbKilled et nbSpared ne peuvent qu'augmenter (pas de setter direct).
    int getNbKilled() const { return nbKilled_; }
    int getNbSpared() const { return nbSpared_; }
    void incrementKilled()  { nbKilled_++; }
    void incrementSpared()  { nbSpared_++; }

    // Accès direct conservé pour compatibilité avec game.cpp
    int& nbKilled = nbKilled_;
    int& nbSpared = nbSpared_;
    int  victory  = 0;

    Player(const std::string& name, float hp, float hpMax,
           float baseDommage, float baseDefense,
           PowerClass powerClass, std::vector<Action*> powerActions)
        : Entity(name, hp, hpMax, baseDommage, baseDefense),
          level(1), xp(0), gold(0),
          powerClass(powerClass), powerActions(powerActions),
          victory(0),
          nbKilled_(0), nbSpared_(0) {}

    void gainXP(int amount, std::vector<std::string>* log = nullptr);
    void resetRunStats();

    // Implémentation de la méthode virtuelle pure d'Entity
    // Le joueur est contrôlé par l'interface — no-op ici.
    void playTurn(Entity* target,
                  std::vector<std::string>* log = nullptr) override {}

    int  consumableCount() const;

    bool equipItem(Item* item, std::vector<std::string>* log = nullptr,
                   int ringSlot = -1);
    void unequipSlot(EquipSlot slot, int ringIndex = 0,
                     std::vector<std::string>* log = nullptr);
    void rebuildActions();

private:
    // Privés — lecture via getNbKilled()/getNbSpared()
    // Ces compteurs ne font qu'augmenter pendant un run.
    int nbKilled_ = 0;
    int nbSpared_ = 0;
};