#include <algorithm>
#include "entity.h"

#define LOG(msg) if(log) log->push_back(msg)

void Entity::tickEffects(std::vector<std::string>* log)
{
    for (auto& e : activeEffects)
    {
        switch (e.type)
        {
            case ActionType::DOMMAGE_TIME:
                hp -= e.value;
                if (hp < 0) hp = 0;
                LOG(name + " -" + std::to_string((int)e.value) + " HP poison ("
                    + std::to_string(e.duration - 1) + " restant)");
                break;

            case ActionType::HEAL_TIME:
                hp += e.value;
                if (hp > hpMax) hp = hpMax;
                LOG(name + " +" + std::to_string((int)e.value) + " HP regen ("
                    + std::to_string(e.duration - 1) + " restant)");
                break;

            case ActionType::BUFF_ATK_TIME:
                LOG(name + " buff atk actif (" + std::to_string(e.duration - 1) + " restant)");
                break;

            case ActionType::BUFF_DEF_TIME:
                LOG(name + " buff def actif (" + std::to_string(e.duration - 1) + " restant)");
                break;

            case ActionType::DEBUFF_ATK_TIME:
                LOG(name + " debuff atk actif (" + std::to_string(e.duration - 1) + " restant)");
                break;

            case ActionType::DEBUFF_DEF_TIME:
                LOG(name + " debuff def actif (" + std::to_string(e.duration - 1) + " restant)");
                break;

            case ActionType::MERCY_DOMMAGE_TIME:
                mercy += (int)e.value;
                if (mercy > mercyGoal) mercy = mercyGoal;
                LOG(name + " mercy +" + std::to_string((int)e.value)
                    + " (" + std::to_string(mercy) + "/" + std::to_string(mercyGoal) + ")");
                break;

            case ActionType::MERCY_HEAL_TIME:
                mercy -= (int)e.value;
                if (mercy < 0) mercy = 0;
                LOG(name + " mercy -" + std::to_string((int)e.value)
                    + " (" + std::to_string(mercy) + "/" + std::to_string(mercyGoal) + ")");
                break;

            default: break;
        }
        e.duration--;
    }

    // Supprime les effets expirés et annule les buffs/debuffs temporaires
    activeEffects.erase(
        std::remove_if(activeEffects.begin(), activeEffects.end(),
            [this, log](const ActiveEffect& e) {
                if (e.duration <= 0) {
                    if (e.type == ActionType::BUFF_ATK_TIME)   { baseDommage -= e.value; LOG(name + " buff atk expire"); }
                    if (e.type == ActionType::BUFF_DEF_TIME)   { baseDefense -= e.value; LOG(name + " buff def expire"); }
                    if (e.type == ActionType::DEBUFF_ATK_TIME) { baseDommage += e.value; LOG(name + " debuff atk expire"); }
                    if (e.type == ActionType::DEBUFF_DEF_TIME) { baseDefense += e.value; LOG(name + " debuff def expire"); }
                    return true;
                }
                return false;
            }),
        activeEffects.end()
    );
}