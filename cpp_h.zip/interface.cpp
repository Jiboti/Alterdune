#include "interface.h"
#include <algorithm>
#include <cstdio>
#include <cmath>

// ============================================================
//  DONNÉES DE CLASSES (affichage uniquement)
// ============================================================

struct ClassDisplayInfo
{
    const char* name;
    const char* description;
    int         statOffense;
    int         statDefense;
    int         statMercy;
};

struct PowerInfo { const char* name; const char* desc; };

static const ClassDisplayInfo classDisplay[] =
{
    { "Berserker", "Tout dans l'attaque.\nIgnore la pitie, frappe sans relache.", 9, 2, 1 },
    { "Guardian",  "Resistance et endurance.\nProtege et tient sur la duree.",    3, 9, 4 },
    { "Trickster", "Affaiblit et manipule.\nPeut epargner pour en tirer profit.", 5, 4, 9 },
};

// Pouvoirs par classe : nom + description courte
static const PowerInfo classPowers[3][3] =
{
    // Berserker
    {{"RAMPAGE",        "Frappe violente. Degats eleves."},
     {"BERSERKER FURY", "Atk +10 pendant 3 tours."},
     {"ARMOR BREAK",    "Reduit la defense ennemie."}},
    // Guardian
    {{"FORTIFY",        "Defense +8 instantane."},
     {"IRON SKIN",      "Defense +7 pendant 3 tours."},
     {"ENDURE",         "Regeneration HP sur 3 tours."}},
    // Trickster
    {{"HEX",            "Mercy +15 instantane."},
     {"MIND LINK",      "Mercy +8 sur 3 tours."},
     {"ENFEEBLE",       "Atk ennemie -5 sur 3 tours."}}
};
static const int NUM_CLASSES = 3;

// ============================================================
//  CONSTRUCTION / DESTRUCTION
// ============================================================

Interface::Interface()
    : window(), logoSprite(logoTexture), titleSprite(titleTexture) {}

Interface::~Interface()
{
    ImGui::SFML::Shutdown();
}

// ============================================================
//  HELPER AUDIO
// ============================================================

void Interface::playButtonSound()
{
    if (buttonSound) buttonSound->play();
}

// ============================================================
//  INITIALISATION
// ============================================================

bool Interface::initWindow()
{
    window.create(
        sf::VideoMode(sf::VideoMode::getDesktopMode().size),
        "Alterdune", sf::Style::None
    );
    window.setFramerateLimit(60);
    window.setPosition({0, 0});
    return window.isOpen();
}

bool Interface::initImGui()
{
    if (!ImGui::SFML::Init(window)) return false;

    // ── Thème sombre doré ─────────────────────────────────────
    ImGuiStyle& style = ImGui::GetStyle();
    style.WindowRounding    = 8.f;
    style.FrameRounding     = 5.f;
    style.GrabRounding      = 4.f;
    style.PopupRounding     = 6.f;
    style.ScrollbarRounding = 4.f;
    style.TabRounding       = 4.f;
    style.WindowBorderSize  = 1.f;
    style.FrameBorderSize   = 0.f;
    style.ItemSpacing       = ImVec2(8.f, 6.f);
    style.WindowPadding     = ImVec2(12.f, 12.f);
    style.FramePadding      = ImVec2(8.f, 4.f);

    ImVec4* c = style.Colors;
    c[ImGuiCol_WindowBg]             = ImVec4(0.07f, 0.07f, 0.07f, 0.94f);
    c[ImGuiCol_PopupBg]              = ImVec4(0.07f, 0.07f, 0.07f, 0.96f);
    c[ImGuiCol_Border]               = ImVec4(0.35f, 0.28f, 0.08f, 0.60f);
    c[ImGuiCol_FrameBg]              = ImVec4(0.10f, 0.10f, 0.10f, 0.88f);
    c[ImGuiCol_FrameBgHovered]       = ImVec4(0.18f, 0.16f, 0.06f, 0.88f);
    c[ImGuiCol_FrameBgActive]        = ImVec4(0.25f, 0.20f, 0.06f, 1.00f);
    c[ImGuiCol_TitleBg]              = ImVec4(0.06f, 0.06f, 0.06f, 1.00f);
    c[ImGuiCol_TitleBgActive]        = ImVec4(0.12f, 0.10f, 0.03f, 1.00f);
    c[ImGuiCol_CheckMark]            = ImVec4(0.90f, 0.72f, 0.20f, 1.00f);
    c[ImGuiCol_SliderGrab]           = ImVec4(0.80f, 0.64f, 0.18f, 1.00f);
    c[ImGuiCol_SliderGrabActive]     = ImVec4(0.95f, 0.80f, 0.30f, 1.00f);
    c[ImGuiCol_Button]               = ImVec4(0.20f, 0.16f, 0.05f, 1.00f);
    c[ImGuiCol_ButtonHovered]        = ImVec4(0.35f, 0.28f, 0.08f, 1.00f);
    c[ImGuiCol_ButtonActive]         = ImVec4(0.50f, 0.40f, 0.10f, 1.00f);
    c[ImGuiCol_Header]               = ImVec4(0.25f, 0.20f, 0.05f, 0.80f);
    c[ImGuiCol_HeaderHovered]        = ImVec4(0.38f, 0.30f, 0.08f, 0.80f);
    c[ImGuiCol_HeaderActive]         = ImVec4(0.50f, 0.40f, 0.10f, 0.80f);
    c[ImGuiCol_Tab]                  = ImVec4(0.12f, 0.10f, 0.03f, 1.00f);
    c[ImGuiCol_TabHovered]           = ImVec4(0.35f, 0.28f, 0.08f, 1.00f);
    c[ImGuiCol_TabActive]            = ImVec4(0.25f, 0.20f, 0.06f, 1.00f);
    c[ImGuiCol_ScrollbarBg]          = ImVec4(0.05f, 0.05f, 0.05f, 0.80f);
    c[ImGuiCol_ScrollbarGrab]        = ImVec4(0.40f, 0.32f, 0.09f, 1.00f);
    c[ImGuiCol_ScrollbarGrabHovered] = ImVec4(0.55f, 0.44f, 0.12f, 1.00f);
    c[ImGuiCol_Text]                 = ImVec4(0.90f, 0.90f, 0.90f, 1.00f);
    c[ImGuiCol_TextDisabled]         = ImVec4(0.45f, 0.45f, 0.45f, 1.00f);
    c[ImGuiCol_Separator]            = ImVec4(0.30f, 0.24f, 0.07f, 0.80f);
    c[ImGuiCol_ChildBg]              = ImVec4(0.06f, 0.06f, 0.06f, 0.80f);

    // ── Police ────────────────────────────────────────────────
    ImGuiIO& io = ImGui::GetIO();
    io.Fonts->Clear();
    ImFont* font = io.Fonts->AddFontFromFileTTF(
        "Ressources/Font/centurygothic_bold.ttf", 24);
    if (!font)
        io.Fonts->AddFontDefault();

    (void)ImGui::SFML::UpdateFontTexture();
    return true;
}

bool Interface::initAssets()
{
    // Background animé
    const char* framePaths[] = {
        "Ressources/Image/Background_anime/bg_frame_00.png",
        "Ressources/Image/Background_anime/bg_frame_01.png",
        "Ressources/Image/Background_anime/bg_frame_02.png",
        "Ressources/Image/Background_anime/bg_frame_03.png",
        "Ressources/Image/Background_anime/bg_frame_04.png",
        "Ressources/Image/Background_anime/bg_frame_05.png",
        "Ressources/Image/Background_anime/bg_frame_06.png",
        "Ressources/Image/Background_anime/bg_frame_07.png",
        "Ressources/Image/Background_anime/bg_frame_08.png",
        "Ressources/Image/Background_anime/bg_frame_09.png",
    };
    for (const auto& path : framePaths)
    {
        sf::Texture tex;
        if (tex.loadFromFile(path)) {
            tex.setSmooth(true);
            bgFrames.push_back(std::move(tex));
        }
    }

    // Logo écran de chargement
    if (!logoTexture.loadFromFile("Ressources/Image/logoAlter.png")) return false;
    logoTexture.setSmooth(true);
    logoSprite.setTexture(logoTexture, true);

    // Titre menu principal
    if (titleTexture.loadFromFile("Ressources/Image/Titre.png"))
    {
        titleTexture.setSmooth(true);
        titleSprite.setTexture(titleTexture, true);
    }

    // Icône fenêtre (barre des tâches + alt+tab)
    {
        sf::Image icon;
        if (icon.loadFromFile("Ressources/Image/logoAlter.png"))
            window.setIcon(icon.getSize(), icon.getPixelsPtr());
    }

    // Musique
    if (!baseMusic.openFromFile("Ressources/Audio/musiqueAll.wav")) return false;
    baseMusic.setLooping(true);
    baseMusic.play();

    // Son bouton
    if (!buttonSoundBuffer.loadFromFile("Ressources/Audio/button.wav")) return false;
    buttonSound = std::make_unique<sf::Sound>(buttonSoundBuffer);
    buttonSound->setPitch(1.5f);

    return true;
}

// ============================================================
//  POINT D'ENTRÉE
// ============================================================

void Interface::run(Game& game)
{
    if (!initWindow()) return;
    if (!initImGui())  return;
    if (!initAssets()) return;

    while (window.isOpen())
    {
        processEvents(game);

        sf::Time dt = deltaClock.restart();
        ImGui::SFML::Update(window, dt);

        update(game, dt.asSeconds());
        render(game);

        window.clear();
        ImGui::SFML::Render(window);
        window.display();
    }
}

// ============================================================
//  EVENTS
// ============================================================

void Interface::processEvents(Game& game)
{
    while (const std::optional event = window.pollEvent())
    {
        ImGui::SFML::ProcessEvent(window, *event);

        if (const auto* key = event->getIf<sf::Event::KeyPressed>())
            if (key->code == sf::Keyboard::Key::Escape)
                window.close();

        if (event->is<sf::Event::Closed>())
            window.close();
    }
}

// ============================================================
//  UPDATE
// ============================================================

void Interface::startFade(GameScreen target)
{
    // Ne déclenche pas si un fondu est déjà en cours
    if (fadeState != FadeState::NONE) return;
    fadeTarget = target;
    fadeState  = FadeState::FADE_OUT;
    fadeAlpha  = 0.f;
}

void Interface::update(Game& game, float dt)
{
    // Animation fond
    if (!bgFrames.empty())
    {
        frameElapsed += dt;
        if (frameElapsed >= frameInterval)
        {
            frameElapsed = 0.f;
            currentFrame = (currentFrame + 1) % (int)bgFrames.size();
        }
    }

    // Note: sliderVolMusic/sliderVolFx sont synchés à l'entrée de renderOptions uniquement

    // ── Chargement au démarrage ───────────────────────────────
    if (game.screen == GameScreen::LOADING)
    {
        if (!dataLoaded)
        {
            loadingMessage = "Chargement des donnees...";
            game.loadData();
            loadingMessage = "Chargement de la sauvegarde...";
            game.loadSave();
            loadingMessage = "";
            dataLoaded = true;
        }

        // Une fois chargé, attendre une interaction utilisateur
        if (dataLoaded && fadeState == FadeState::NONE)
        {
            ImGuiIO& io = ImGui::GetIO();
            bool anyInput = io.MouseClicked[0]
                         || io.MouseClicked[1]
                         || ImGui::IsKeyPressed(ImGuiKey_Space)
                         || ImGui::IsKeyPressed(ImGuiKey_Enter)
                         || ImGui::IsKeyPressed(ImGuiKey_Escape)
                         || io.InputQueueCharacters.Size > 0;
            if (anyInput)
                startFade(GameScreen::MENU);
        }
    }

    // ── Fondu noir ────────────────────────────────────────────
    if (fadeState == FadeState::FADE_OUT)
    {
        fadeAlpha += fadeSpeed * dt;
        if (fadeAlpha >= 1.f)
        {
            fadeAlpha      = 1.f;
            game.screen    = fadeTarget; // changement d'écran au pic noir
            fadeState      = FadeState::FADE_IN;
        }
    }
    else if (fadeState == FadeState::FADE_IN)
    {
        fadeAlpha -= fadeSpeed * dt;
        if (fadeAlpha <= 0.f)
        {
            fadeAlpha  = 0.f;
            fadeState  = FadeState::NONE;
        }
    }
}

// ============================================================
//  DISPATCH RENDU
// ============================================================

void Interface::render(Game& game)
{
    switch (game.screen)
    {
        case GameScreen::LOADING:         renderLoading(game);        break;
        case GameScreen::MENU:            renderMenu(game);           break;
        case GameScreen::OPTIONS:         renderOptions(game);        break;
        case GameScreen::STAT_COLLECTION: renderStatCollection(game); break;
        case GameScreen::CLASS_SELECT:    renderClassSelect(game);    break;
        case GameScreen::COMBAT:          renderCombat(game);         break;
        case GameScreen::INTERMEDIATE:    renderIntermediate(game);   break;
        case GameScreen::END_RUN:         renderEndRun(game);         break;
        default: break;
    }

    // Popup pause — s'affiche par-dessus n'importe quel écran de run
    if (paused && game.isRunActive())
        renderPause(game);

    // ── Fondu noir — par-dessus tout ─────────────────────────
    if (fadeState != FadeState::NONE && fadeAlpha > 0.f)
    {
        ImDrawList* fdl = ImGui::GetForegroundDrawList();
        ImU32 col = ImGui::GetColorU32(ImVec4(0.f, 0.f, 0.f, fadeAlpha));
        float scrW = (float)window.getSize().x;
        float scrH = (float)window.getSize().y;
        fdl->AddRectFilled(ImVec2(0, 0), ImVec2(scrW, scrH), col);
    }

    // ── Bloqueur d'input pendant le fondu ────────────────────
    // Fenêtre transparente fullscreen qui capture tous les clics
    if (fadeState != FadeState::NONE)
    {
        float scrW = (float)window.getSize().x;
        float scrH = (float)window.getSize().y;
        ImGui::SetNextWindowPos(ImVec2(0, 0));
        ImGui::SetNextWindowSize(ImVec2(scrW, scrH));
        ImGui::SetNextWindowBgAlpha(0.f);
        ImGui::Begin("##fade_blocker", nullptr,
            ImGuiWindowFlags_NoDecoration   |
            ImGuiWindowFlags_NoMove         |
            ImGuiWindowFlags_NoSavedSettings|
            ImGuiWindowFlags_NoNav          |
            ImGuiWindowFlags_NoScrollbar    |
            ImGuiWindowFlags_NoTitleBar);
        ImGui::End();
    }
}

// ============================================================
//  HELPER : FENÊTRE PLEIN ÉCRAN
// ============================================================

bool Interface::beginFullscreen(const char* id)
{
    bool opened = true;
    ImGui::SetNextWindowSize(ImVec2((float)window.getSize().x,
                                   (float)window.getSize().y));
    ImGui::SetNextWindowPos(ImVec2(0, 0));
    return ImGui::Begin(id, &opened,
        ImGuiWindowFlags_NoCollapse  | ImGuiWindowFlags_NoResize |
        ImGuiWindowFlags_NoTitleBar  | ImGuiWindowFlags_NoBackground);
}

// ============================================================
//  WIDGETS PARTAGÉS
// ============================================================

void Interface::drawBackground()
{
    if (!bgFrames.empty())
    {
        ImGui::SetCursorPos({0, 0});
        ImGui::Image(bgFrames[currentFrame]);
    }
    float winW = ImGui::GetWindowWidth();
    float winH = ImGui::GetWindowHeight();
    // Titre du menu
    if (titleTexture.getSize().x > 0)
    {
        float titleW = (float)titleTexture.getSize().x;
        ImGui::SetCursorPosX((winW - titleW) * 0.5f);
        ImGui::SetCursorPosY(winH * 0.10f);
        ImGui::Image(titleSprite);
    }
}

void Interface::drawBar(ImDrawList* dl, ImVec2 pos, float width, float height,
                        float value, float maxValue,
                        ImVec4 color, const char* label)
{
    float ratio = (maxValue > 0.f) ? std::clamp(value / maxValue, 0.f, 1.f) : 0.f;

    dl->AddRectFilled(pos, ImVec2(pos.x + width, pos.y + height),
        ImGui::GetColorU32(ImVec4(0.15f, 0.15f, 0.15f, 1.f)), 4.f);
    dl->AddRectFilled(pos, ImVec2(pos.x + width * ratio, pos.y + height),
        ImGui::GetColorU32(color), 4.f);
    dl->AddRect(pos, ImVec2(pos.x + width, pos.y + height),
        ImGui::GetColorU32(ImVec4(0.4f, 0.4f, 0.4f, 1.f)), 4.f);

    char buf[64];
    snprintf(buf, sizeof(buf), "%s %.0f/%.0f", label, value, maxValue);
    ImVec2 tSize = ImGui::CalcTextSize(buf);
    dl->AddText(
        ImVec2(pos.x + width * 0.5f - tSize.x * 0.5f,
               pos.y + (height - tSize.y) * 0.5f),
        ImGui::GetColorU32(ImVec4(1.f, 1.f, 1.f, 0.9f)), buf
    );
}

bool Interface::actionButton(const char* label, ImVec2 size, bool disabled,
                             const char* tooltip)
{
    ImGui::PushID(label);
    if (disabled) ImGui::BeginDisabled();

    ImVec2 p       = ImGui::GetCursorScreenPos();
    bool   clicked = ImGui::InvisibleButton(label, size);
    bool   hovered = ImGui::IsItemHovered();
    ImDrawList* dl = ImGui::GetWindowDrawList();

    ImU32 bg = disabled
        ? ImGui::GetColorU32(ImVec4(0.10f, 0.10f, 0.10f, 0.50f))
        : hovered
            ? ImGui::GetColorU32(ImVec4(0.35f, 0.30f, 0.10f, 1.f))
            : ImGui::GetColorU32(ImVec4(0.20f, 0.18f, 0.08f, 1.f));
    ImU32 border = disabled
        ? ImGui::GetColorU32(ImVec4(0.30f, 0.30f, 0.30f, 0.50f))
        : ImGui::GetColorU32(ImVec4(0.80f, 0.65f, 0.20f, 1.f));

    dl->AddRectFilled(p, ImVec2(p.x + size.x, p.y + size.y), bg, 6.f);
    dl->AddRect(p, ImVec2(p.x + size.x, p.y + size.y), border, 6.f, 0, 1.5f);

    // Tronquer le label avant '##' (convention ImGui — ## invisible à l'affichage)
    std::string displayLabel(label);
    auto sep = displayLabel.find("##");
    if (sep != std::string::npos)
        displayLabel = displayLabel.substr(0, sep);

    ImVec2 tSize = ImGui::CalcTextSize(displayLabel.c_str());
    dl->AddText(
        ImVec2(p.x + (size.x - tSize.x) * 0.5f,
               p.y + (size.y - tSize.y) * 0.5f),
        ImGui::GetColorU32(disabled
            ? ImVec4(0.4f, 0.4f, 0.4f, 1.f)
            : ImVec4(1.f, 1.f, 1.f, 1.f)),
        displayLabel.c_str()
    );

    if (disabled) ImGui::EndDisabled();
    ImGui::PopID();

    // Tooltip au survol
    if (tooltip && hovered && !disabled)
    {
        ImGui::BeginTooltip();
        ImGui::PushTextWrapPos(300.f);
        ImGui::TextUnformatted(tooltip);
        ImGui::PopTextWrapPos();
        ImGui::EndTooltip();
    }

    return clicked && !disabled;
}

bool Interface::classCard(int classIndex, ImVec2 size, bool selected)
{
    const ClassDisplayInfo& info = classDisplay[classIndex];
    ImGui::PushID(info.name);

    ImVec2 p       = ImGui::GetCursorScreenPos();
    bool   clicked = ImGui::InvisibleButton(info.name, size);
    bool   hovered = ImGui::IsItemHovered();
    ImDrawList* dl = ImGui::GetWindowDrawList();

    ImU32 bgColor = selected
        ? ImGui::GetColorU32(ImVec4(0.25f, 0.18f, 0.05f, 0.95f))
        : hovered
            ? ImGui::GetColorU32(ImVec4(0.22f, 0.22f, 0.22f, 0.92f))
            : ImGui::GetColorU32(ImVec4(0.10f, 0.10f, 0.10f, 0.88f));
    ImU32 borderColor = selected
        ? ImGui::GetColorU32(ImVec4(0.95f, 0.75f, 0.20f, 1.f))
        : ImGui::GetColorU32(ImVec4(0.35f, 0.35f, 0.35f, 1.f));

    dl->AddRectFilled(p, ImVec2(p.x + size.x, p.y + size.y), bgColor, 10.f);
    dl->AddRect(p, ImVec2(p.x + size.x, p.y + size.y), borderColor, 10.f, 0,
                selected ? 3.f : 1.5f);

    float pad = 18.f;
    float cx  = p.x + size.x * 0.5f;
    float y   = p.y + pad;

    ImU32 nameColor = selected
        ? ImGui::GetColorU32(ImVec4(1.f, 0.85f, 0.35f, 1.f))
        : ImGui::GetColorU32(ImVec4(1.f, 1.f, 1.f, 1.f));
    ImVec2 nameSize = ImGui::CalcTextSize(info.name);
    dl->AddText(ImVec2(cx - nameSize.x * 0.5f, y), nameColor, info.name);
    y += nameSize.y + pad * 0.5f;

    dl->AddLine(ImVec2(p.x + pad, y), ImVec2(p.x + size.x - pad, y),
                ImGui::GetColorU32(ImVec4(0.5f, 0.5f, 0.5f, 0.5f)));
    y += pad;

    dl->AddText(nullptr, 0.f,
        ImVec2(p.x + pad, y),
        ImGui::GetColorU32(ImVec4(0.80f, 0.80f, 0.80f, 1.f)),
        info.description, nullptr, size.x - 2.f * pad);
    y += 70.f;

    auto drawStat = [&](const char* statLabel, int val, ImVec4 color)
    {
        dl->AddText(ImVec2(p.x + pad, y),
            ImGui::GetColorU32(ImVec4(0.75f, 0.75f, 0.75f, 1.f)), statLabel);
        float barX = p.x + pad + 95.f;
        float barW = size.x - pad - 95.f - pad;
        float barH = 10.f;
        float barY = y + 7.f;
        dl->AddRectFilled(ImVec2(barX, barY), ImVec2(barX + barW, barY + barH),
            ImGui::GetColorU32(ImVec4(0.2f, 0.2f, 0.2f, 1.f)), 4.f);
        dl->AddRectFilled(ImVec2(barX, barY),
            ImVec2(barX + barW * (val / 10.f), barY + barH),
            ImGui::GetColorU32(color), 4.f);
        y += 28.f;
    };

    drawStat("Attaque", info.statOffense, ImVec4(0.9f, 0.3f, 0.2f, 1.f));
    drawStat("Defense", info.statDefense, ImVec4(0.3f, 0.6f, 0.9f, 1.f));
    drawStat("Pitie",   info.statMercy,   ImVec4(0.6f, 0.9f, 0.4f, 1.f));

    // Séparateur
    y += 6.f;
    dl->AddLine(ImVec2(p.x + pad, y), ImVec2(p.x + size.x - pad, y),
                ImGui::GetColorU32(ImVec4(0.35f, 0.35f, 0.35f, 0.5f)));
    y += 10.f;

    // Pouvoirs
    dl->AddText(ImVec2(p.x + pad, y),
                ImGui::GetColorU32(ImVec4(0.7f, 0.55f, 0.9f, 1.f)), "Pouvoirs :");
    y += 18.f;

    for (int pi = 0; pi < 3; pi++)
    {
        const PowerInfo& pw = classPowers[classIndex][pi];
        // Nom du pouvoir
        dl->AddText(ImVec2(p.x + pad, y),
                    ImGui::GetColorU32(selected
                        ? ImVec4(1.f, 0.85f, 0.35f, 1.f)
                        : ImVec4(0.85f, 0.85f, 0.85f, 1.f)),
                    pw.name);
        y += 16.f;
        // Description
        dl->AddText(nullptr, 0.f,
                    ImVec2(p.x + pad + 8.f, y),
                    ImGui::GetColorU32(ImVec4(0.55f, 0.55f, 0.55f, 1.f)),
                    pw.desc, nullptr, size.x - 2.f * pad - 8.f);
        y += 26.f;
    }

    ImGui::PopID();
    return clicked;
}

const char* Interface::effectLabel(ActionType type)
{
    switch (type)
    {
        case ActionType::DOMMAGE_TIME:       return "Poison";
        case ActionType::HEAL_TIME:          return "Regen";
        case ActionType::BUFF_ATK_TIME:      return "Atk+";
        case ActionType::BUFF_DEF_TIME:      return "Def+";
        case ActionType::DEBUFF_ATK_TIME:    return "Atk-";
        case ActionType::DEBUFF_DEF_TIME:    return "Def-";
        case ActionType::MERCY_DOMMAGE_TIME: return "MrcyDmg";
        case ActionType::MERCY_HEAL_TIME:    return "MrcyHeal";
        default:                             return "Effet";
    }
}

void Interface::drawPanel(ImDrawList* dl, float x, float y,
                          float w, float h, ImVec4 borderColor)
{
    dl->AddRectFilled(ImVec2(x, y), ImVec2(x + w, y + h),
        ImGui::GetColorU32(ImVec4(0.08f, 0.08f, 0.08f, 0.88f)), 10.f);
    dl->AddRect(ImVec2(x, y), ImVec2(x + w, y + h),
        ImGui::GetColorU32(borderColor), 10.f, 0, 1.5f);
}

void Interface::drawSectionTitle(ImDrawList* dl, float panelX, float panelY,
                                 float panelW, const char* title, ImVec4 color)
{
    ImVec2 tSize = ImGui::CalcTextSize(title);
    dl->AddText(
        ImVec2(panelX + (panelW - tSize.x) * 0.5f, panelY + 10.f),
        ImGui::GetColorU32(color), title
    );
}

// drawItemIcon supprimé

// Retourne couleur + label pour chaque type d'effet
static void effectStyle(ActionType type,
                        const char*& label, ImVec4& bgCol, ImVec4& textCol)
{
    switch (type)
    {
        case ActionType::DOMMAGE_TIME:
            label = "Poison"; bgCol = {0.5f,0.1f,0.5f,0.9f}; textCol = {1.f,0.7f,1.f,1.f}; break;
        case ActionType::HEAL_TIME:
            label = "Regen";  bgCol = {0.1f,0.5f,0.2f,0.9f}; textCol = {0.6f,1.f,0.7f,1.f}; break;
        case ActionType::BUFF_ATK_TIME:
            label = "Atk+";   bgCol = {0.6f,0.2f,0.1f,0.9f}; textCol = {1.f,0.8f,0.6f,1.f}; break;
        case ActionType::BUFF_DEF_TIME:
            label = "Def+";   bgCol = {0.1f,0.3f,0.6f,0.9f}; textCol = {0.6f,0.8f,1.f,1.f}; break;
        case ActionType::DEBUFF_ATK_TIME:
            label = "Atk-";   bgCol = {0.4f,0.1f,0.1f,0.9f}; textCol = {1.f,0.5f,0.5f,1.f}; break;
        case ActionType::DEBUFF_DEF_TIME:
            label = "Def-";   bgCol = {0.1f,0.1f,0.4f,0.9f}; textCol = {0.6f,0.6f,1.f,1.f}; break;
        case ActionType::MERCY_DOMMAGE_TIME:
            label = "Mrcy+";  bgCol = {0.1f,0.4f,0.5f,0.9f}; textCol = {0.5f,0.9f,1.f,1.f}; break;
        case ActionType::MERCY_HEAL_TIME:
            label = "Mrcy-";  bgCol = {0.4f,0.3f,0.1f,0.9f}; textCol = {1.f,0.85f,0.4f,1.f}; break;
        default:
            label = "Effet";  bgCol = {0.2f,0.2f,0.2f,0.9f}; textCol = {0.9f,0.9f,0.9f,1.f}; break;
    }
}

void Interface::drawEffectBadges(ImDrawList* dl,
                                  const std::vector<ActiveEffect>& effects,
                                  ImVec2 startPos, float maxWidth)
{
    if (effects.empty()) return;

    float x     = startPos.x;
    float y     = startPos.y;
    float badgeH = 20.f;
    float padX   = 6.f;
    float padY   = 4.f;
    float gap    = 4.f;

    for (const auto& eff : effects)
    {
        const char* label = "";
        ImVec4 bgCol, textCol;
        effectStyle(eff.type, label, bgCol, textCol);

        // Format "Label Xt"
        char buf[16];
        snprintf(buf, sizeof(buf), "%s %dt", label, eff.duration);

        ImVec2 tSz  = ImGui::CalcTextSize(buf);
        float  badgeW = tSz.x + 2.f * padX;

        // Retour à la ligne si on dépasse maxWidth
        if (x + badgeW > startPos.x + maxWidth && x > startPos.x)
        {
            x  = startPos.x;
            y += badgeH + gap;
        }

        // Fond du badge
        dl->AddRectFilled(ImVec2(x, y),
                          ImVec2(x + badgeW, y + badgeH),
                          ImGui::GetColorU32(bgCol), 4.f);
        // Bordure légère
        dl->AddRect(ImVec2(x, y),
                    ImVec2(x + badgeW, y + badgeH),
                    ImGui::GetColorU32(ImVec4(1.f,1.f,1.f,0.15f)), 4.f);
        // Texte
        dl->AddText(ImVec2(x + padX, y + padY),
                    ImGui::GetColorU32(textCol), buf);

        x += badgeW + gap;
    }
}

// ============================================================
//  RENDU — CHARGEMENT
// ============================================================

void Interface::renderLoading(Game& game)
{
    if (!beginFullscreen("##loading")) { ImGui::End(); return; }

    // Fond animé si disponible, sinon noir
    if (!bgFrames.empty())
    {
        ImGui::SetCursorPos({0, 0});
        ImGui::Image(bgFrames[currentFrame]);
    }

    float winW = ImGui::GetWindowWidth();
    float winH = ImGui::GetWindowHeight();
    ImDrawList* dl  = ImGui::GetWindowDrawList();
    ImVec2      wPos = ImGui::GetWindowPos();

    // Logo centré en haut
    if (logoTexture.getSize().x > 0)
    {
        float logoW = (float)logoTexture.getSize().x;
        float logoH = (float)logoTexture.getSize().y;
        ImGui::SetCursorPos(ImVec2((winW - logoW) * 0.5f, winH * 0.10f));
        ImGui::Image(logoSprite);
    }

    // Message de chargement / invitation
    ImVec2 msgSz = ImGui::CalcTextSize(loadingMessage.c_str());
    dl->AddText(
        ImVec2(wPos.x + (winW - msgSz.x) * 0.5f, wPos.y + winH * 0.68f),
        ImGui::GetColorU32(ImVec4(0.75f, 0.75f, 0.75f, 1.f)),
        loadingMessage.c_str());

    if (!dataLoaded)
    {
        // Barre de chargement animée (dots)
        float barW = winW * 0.35f;
        float barH = 8.f;
        float barX = wPos.x + (winW - barW) * 0.5f;
        float barY = wPos.y + winH * 0.73f;

        // Animation : barre qui avance et revient
        float t = fmod((float)ImGui::GetTime() * 0.8f, 1.f);
        dl->AddRectFilled(ImVec2(barX, barY),
                          ImVec2(barX + barW, barY + barH),
                          ImGui::GetColorU32(ImVec4(0.15f, 0.15f, 0.15f, 1.f)), 4.f);
        dl->AddRectFilled(ImVec2(barX, barY),
                          ImVec2(barX + barW * t, barY + barH),
                          ImGui::GetColorU32(ImVec4(0.6f, 0.45f, 0.1f, 1.f)), 4.f);
        dl->AddRect(ImVec2(barX, barY),
                    ImVec2(barX + barW, barY + barH),
                    ImGui::GetColorU32(ImVec4(0.4f, 0.4f, 0.4f, 0.6f)), 4.f);
    }
    else
    {
        // Texte clignotant "Appuyez pour continuer"
        float blink = sinf((float)ImGui::GetTime() * 3.f) * 0.5f + 0.5f;
        const char* prompt = "[ Cliquez ou appuyez sur une touche ]";
        ImVec2 pSz = ImGui::CalcTextSize(prompt);
        dl->AddText(
            ImVec2(wPos.x + (winW - pSz.x) * 0.5f, wPos.y + winH * 0.74f),
            ImGui::GetColorU32(ImVec4(0.8f, 0.65f, 0.2f, blink)), prompt);
    }

    // Version discrète en bas
    const char* version = "Alterdune  v0.1";
    ImVec2 vSz = ImGui::CalcTextSize(version);
    dl->AddText(
        ImVec2(wPos.x + (winW - vSz.x) * 0.5f, wPos.y + winH * 0.92f),
        ImGui::GetColorU32(ImVec4(0.3f, 0.3f, 0.3f, 1.f)), version);

    ImGui::End();
}

// ============================================================
//  RENDU — MENU PRINCIPAL
// ============================================================

void Interface::renderMenu(Game& game)
{
    if (!beginFullscreen("##menu")) { ImGui::End(); return; }

    drawBackground();

    float winW  = ImGui::GetWindowWidth();
    float winH  = ImGui::GetWindowHeight();
    float btnW  = winW / 4.f;
    float btnH  = winH / 20.f;
    float btnX  = winW * 0.5f - btnW * 0.5f;
    float baseY = winH * 0.5f;
    float step  = btnH + 25.f;
    int   row   = 0;

    if (game.isRunActive())
    {
        ImGui::SetCursorPos(ImVec2(btnX, baseY + row * step));
        if (actionButton("Reprendre", ImVec2(btnW, btnH)))
        {
            playButtonSound();
            // Restaure le bon écran selon l'état du run
            if (game.currentMonster.has_value())
                game.screen = GameScreen::COMBAT;
            else
                game.screen = GameScreen::INTERMEDIATE;
        }
        row++;
    }

    ImGui::SetCursorPos(ImVec2(btnX, baseY + row * step));
    if (actionButton("Nouvelle partie", ImVec2(btnW, btnH)))
    {
        playButtonSound();
        selectedClass = -1;
        memset(seedInput, 0, sizeof(seedInput));
        memset(nameInput, 0, sizeof(nameInput));
        game.startRun();
    }
    row++;

    ImGui::SetCursorPos(ImVec2(btnX, baseY + row * step));
    if (actionButton("Stats & Collection", ImVec2(btnW, btnH)))
    {
        playButtonSound();
        startFade(GameScreen::STAT_COLLECTION);
    }
    row++;

    ImGui::SetCursorPos(ImVec2(btnX, baseY + row * step));
    if (actionButton("Options", ImVec2(btnW, btnH)))
    {
        playButtonSound();
        startFade(GameScreen::OPTIONS);
    }
    row++;

    ImGui::SetCursorPos(ImVec2(btnX, baseY + row * step));
    if (actionButton("Quitter", ImVec2(btnW, btnH)))
    {
        playButtonSound();
        window.close();
    }

    ImGui::End();
}

// ============================================================
//  RENDU — OPTIONS
// ============================================================

void Interface::renderOptions(Game& game)
{
    if (!beginFullscreen("##options")) { ImGui::End(); return; }

    // Sync initial — on récupère les valeurs courantes du jeu
    if (ImGui::IsWindowAppearing())
    {
        sliderVolMusic = game.volumeMusic;
        sliderVolFx    = game.volumeFx;
    }

    drawBackground();

    float winW = ImGui::GetWindowWidth();
    float winH = ImGui::GetWindowHeight();
    float btnW = winW / 4.f;
    float btnH = winH / 20.f;
    float btnX = winW * 0.5f - btnW * 0.5f;

    ImGui::PushStyleColor(ImGuiCol_SliderGrab,     ImVec4(0.80f, 0.65f, 0.20f, 1.f));
    ImGui::PushStyleColor(ImGuiCol_SliderGrabActive, ImVec4(0.95f, 0.80f, 0.35f, 1.f));
    ImGui::PushStyleColor(ImGuiCol_FrameBg,        ImVec4(0.10f, 0.10f, 0.10f, 0.90f));
    ImGui::PushStyleColor(ImGuiCol_FrameBgHovered, ImVec4(0.18f, 0.18f, 0.18f, 0.90f));

    ImGui::SetCursorPos(ImVec2(winW / 6.f, winH * 0.5f));
    ImGui::SetNextItemWidth(winW / 2.5f);
    ImGui::SliderInt("Volume Musique", &sliderVolMusic, 0, 100);

    ImGui::SetCursorPos(ImVec2(winW / 6.f, winH * 0.5f + btnH + 25.f));
    ImGui::SetNextItemWidth(winW / 2.5f);
    ImGui::SliderInt("Volume FX", &sliderVolFx, 0, 100);

    ImGui::PopStyleColor(4);

    ImGui::SetCursorPos(ImVec2(btnX, winH * 0.5f + 4.f * btnH + 100.f));
    if (actionButton("Appliquer", ImVec2(btnW, btnH)))
    {
        playButtonSound();
        game.volumeMusic = sliderVolMusic;
        game.volumeFx    = sliderVolFx;
        baseMusic.setVolume((float)sliderVolMusic);
        if (buttonSound) buttonSound->setVolume((float)sliderVolFx);
    }

    ImGui::SetCursorPos(ImVec2(btnX, winH * 0.5f + 5.f * btnH + 125.f));
    if (actionButton("Retour", ImVec2(btnW, btnH)))
    {
        playButtonSound();
        startFade(GameScreen::MENU);
    }

    ImGui::End();
}

// ============================================================
//  RENDU — STATS & COLLECTION
// ============================================================

void Interface::renderStatCollection(Game& game)
{
    if (!beginFullscreen("##statcollection")) { ImGui::End(); return; }

    drawBackground();

    float winW = ImGui::GetWindowWidth();
    float winH = ImGui::GetWindowHeight();
    ImDrawList* dl = ImGui::GetWindowDrawList();

    float contW = winW * 0.90f;
    float contH = winH * 0.75f;
    float contX = (winW - contW) * 0.5f;
    float contY = winH * 0.10f;
    float pad   = 18.f;

    drawPanel(dl, contX, contY, contW, contH, ImVec4(0.4f, 0.4f, 0.6f, 0.7f));

    ImGui::SetCursorPos(ImVec2(contX + pad, contY + pad));
    ImGui::BeginTabBar("##tabs_stat");

    // =========================================================================
    //  ONGLET 1 — STATS DU JOUEUR
    // =========================================================================
    if (ImGui::BeginTabItem("Stats du joueur"))
    {
        float tabY = contY + 60.f;
        float col1 = contX + pad;
        float col2 = contX + contW * 0.50f;

        if (!game.currentPlayer.has_value())
        {
            ImGui::SetCursorPos(ImVec2(col1, tabY + contH * 0.35f));
            ImGui::TextDisabled("Aucun run en cours — lancez une nouvelle partie");
        }
        else
        {
            const Player& p = game.currentPlayer.value();

            auto drawLine = [&](const char* label, const char* val, float& y, float col)
            {
                char buf[128];
                snprintf(buf, sizeof(buf), "%-22s %s", label, val);
                dl->AddText(ImVec2(col, y),
                    ImGui::GetColorU32(ImVec4(0.9f, 0.9f, 0.9f, 1.f)), buf);
                y += 28.f;
            };
            auto drawLineInt = [&](const char* label, int val, float& y, float col)
            {
                char tmp[32];
                snprintf(tmp, sizeof(tmp), "%d", val);
                drawLine(label, tmp, y, col);
            };
            auto drawLineFloat = [&](const char* label, float val, float& y, float col)
            {
                char tmp[32];
                snprintf(tmp, sizeof(tmp), "%.1f", val);
                drawLine(label, tmp, y, col);
            };

            dl->AddText(ImVec2(col1, tabY),
                ImGui::GetColorU32(ImVec4(0.6f, 0.85f, 1.f, 1.f)),
                "=== IDENTITE & PROGRESSION ===");
            tabY += 30.f;

            float y1 = tabY;
            drawLine    ("Nom",           p.name.c_str(),    y1, col1);
            {
                const char* cls =
                    p.powerClass == PowerClass::BERSERKER ? "Berserker" :
                    p.powerClass == PowerClass::GUARDIAN  ? "Guardian"  :
                                                            "Trickster";
                drawLine("Classe",        cls,               y1, col1);
            }
            drawLineInt ("Niveau",        p.level,           y1, col1);
            drawLineInt ("XP",            p.xp,              y1, col1);
            drawLineInt ("Or",            p.gold,            y1, col1);
            drawLineInt ("Combat n",      game.combatNumber, y1, col1);

            float titleY2 = tabY - 30.f;
            dl->AddText(ImVec2(col2, titleY2),
                ImGui::GetColorU32(ImVec4(1.f, 0.75f, 0.35f, 1.f)),
                "=== COMBAT & SANTE ===");
            titleY2 += 30.f;

            float y2 = titleY2;
            drawLineFloat("HP actuel",    p.hp,              y2, col2);
            drawLineFloat("HP max",       p.hpMax,           y2, col2);
            drawLineFloat("Attaque",      p.baseDommage,     y2, col2);
            drawLineFloat("Defense",      p.baseDefense,     y2, col2);

            y2 += 10.f;
            dl->AddLine(ImVec2(col2, y2), ImVec2(col2 + contW * 0.4f, y2),
                ImGui::GetColorU32(ImVec4(0.4f, 0.4f, 0.4f, 0.5f)));
            y2 += 14.f;

            // nbKilled / nbSpared (noms issus du refactor)
            drawLineInt ("Monstres tues",     p.nbKilled,  y2, col2);
            drawLineInt ("Monstres epargnes", p.nbSpared,  y2, col2);
            drawLineInt ("Victoires",         p.victory,   y2, col2);

            // Barre HP
            float barY = tabY + 6.f * 28.f + 20.f;
            ImGui::SetCursorPos(ImVec2(col1, barY));
            drawBar(dl, ImGui::GetCursorScreenPos(),
                    contW * 0.40f, 16.f,
                    p.hp, p.hpMax,
                    ImVec4(0.2f, 0.8f, 0.3f, 1.f), "HP");
            ImGui::Dummy(ImVec2(contW * 0.40f, 22.f));

            // Inventaire résumé
            float invY = barY + 46.f;
            dl->AddText(ImVec2(col1, invY),
                ImGui::GetColorU32(ImVec4(0.75f, 0.75f, 0.75f, 1.f)),
                "-- Inventaire --");
            invY += 24.f;

            if (p.inventory.slots.empty())
            {
                dl->AddText(ImVec2(col1 + 10.f, invY),
                    ImGui::GetColorU32(ImVec4(0.5f, 0.5f, 0.5f, 1.f)), "Vide");
            }
            else
            {
                for (const auto& slot : p.inventory.slots)
                {
                    const char* typeStr =
                        (slot.item->type == ItemType::EQUIPPABLE) ? "Equip." : "Conso.";
                    char ibuf[128];
                    snprintf(ibuf, sizeof(ibuf), "  %-24s x%d  (%s)",
                             slot.item->name.c_str(), slot.quantity, typeStr);
                    dl->AddText(ImVec2(col1, invY),
                        ImGui::GetColorU32(ImVec4(0.85f, 0.85f, 0.85f, 1.f)), ibuf);
                    invY += 22.f;
                    if (invY > contY + contH - pad * 2.f) break;
                }
            }

            // ── Pouvoirs de classe (colonne droite, bas) ──────
            int classIdx =
                p.powerClass == PowerClass::BERSERKER ? 0 :
                p.powerClass == PowerClass::GUARDIAN  ? 1 : 2;

            float py = y2 + 20.f;
            dl->AddLine(ImVec2(col2, py), ImVec2(col2 + contW * 0.4f, py),
                ImGui::GetColorU32(ImVec4(0.4f, 0.4f, 0.4f, 0.5f)));
            py += 12.f;

            dl->AddText(ImVec2(col2, py),
                ImGui::GetColorU32(ImVec4(0.7f, 0.55f, 0.9f, 1.f)),
                "=== POUVOIRS ===");
            py += 26.f;

            for (int pi = 0; pi < 3; pi++)
            {
                const PowerInfo& pw = classPowers[classIdx][pi];

                // Disponible ou utilisé
                bool used = !p.usePower;
                ImVec4 nameCol = used
                    ? ImVec4(0.45f, 0.45f, 0.45f, 1.f)
                    : ImVec4(1.f, 0.85f, 0.35f, 1.f);

                dl->AddText(ImVec2(col2, py),
                    ImGui::GetColorU32(nameCol), pw.name);
                py += 18.f;
                dl->AddText(nullptr, 0.f, ImVec2(col2 + 10.f, py),
                    ImGui::GetColorU32(ImVec4(0.55f, 0.55f, 0.55f, 1.f)),
                    pw.desc, nullptr, contW * 0.42f);
                py += 24.f;

                if (py > contY + contH - pad * 2.f) break;
            }
        }

        ImGui::EndTabItem();
    }

    // =========================================================================
    //  ONGLET 2 — BESTIAIRE
    // =========================================================================
    if (ImGui::BeginTabItem("Bestiaire"))
    {
        float tabY = contY + 60.f;

        float cName = contX + pad;
        float cCat  = contX + contW * 0.22f;
        float cHP   = contX + contW * 0.34f;
        float cAtk  = contX + contW * 0.44f;
        float cDef  = contX + contW * 0.54f;
        float cMerc = contX + contW * 0.64f;
        float cStat = contX + contW * 0.78f;

        ImU32 hdrColor = ImGui::GetColorU32(ImVec4(0.7f, 0.7f, 0.7f, 1.f));
        dl->AddText(ImVec2(cName, tabY), hdrColor, "Nom");
        dl->AddText(ImVec2(cCat,  tabY), hdrColor, "Categorie");
        dl->AddText(ImVec2(cHP,   tabY), hdrColor, "HP");
        dl->AddText(ImVec2(cAtk,  tabY), hdrColor, "ATK");
        dl->AddText(ImVec2(cDef,  tabY), hdrColor, "DEF");
        dl->AddText(ImVec2(cMerc, tabY), hdrColor, "Mercy");
        dl->AddText(ImVec2(cStat, tabY), hdrColor, "Statut");
        tabY += 6.f;
        dl->AddLine(ImVec2(contX + pad, tabY + 16.f),
                    ImVec2(contX + contW - pad, tabY + 16.f),
                    ImGui::GetColorU32(ImVec4(0.4f, 0.4f, 0.5f, 0.8f)));

        ImGui::SetCursorPos(ImVec2(contX + pad, tabY + 24.f));
        ImGui::BeginChild("##bestiary_scroll",
                          ImVec2(contW - pad * 2.f, contH - 100.f), false);

        for (const auto& entry : game.allMonsters)
        {
            const BestiaryEntry* seen = nullptr;
            for (const auto& b : game.bestiary)
                if (b.monsterId == entry.id) { seen = &b; break; }

            ImVec4 nameCol =
                entry.category == MonsterCategory::BOSS      ? ImVec4(1.f,  0.4f, 0.4f, 1.f) :
                entry.category == MonsterCategory::MINI_BOSS ? ImVec4(1.f,  0.75f,0.2f, 1.f) :
                                                               ImVec4(0.9f, 0.9f, 0.9f, 1.f);

            ImDrawList* sdl = ImGui::GetWindowDrawList();
            ImVec2 cursor   = ImGui::GetCursorScreenPos();
            float  lx       = cursor.x;
            float  ly       = cursor.y;

            if (!seen)
            {
                // Monstre non rencontré — tout masqué
                ImU32 unkColor = ImGui::GetColorU32(ImVec4(0.35f, 0.35f, 0.35f, 1.f));
                sdl->AddText(ImVec2(lx, ly), unkColor, "???");
                sdl->AddText(ImVec2(lx + contW * 0.22f - pad, ly), unkColor, "???");
                sdl->AddText(ImVec2(lx + contW * 0.34f - pad, ly), unkColor, "?");
                sdl->AddText(ImVec2(lx + contW * 0.44f - pad, ly), unkColor, "?");
                sdl->AddText(ImVec2(lx + contW * 0.54f - pad, ly), unkColor, "?");
                sdl->AddText(ImVec2(lx + contW * 0.64f - pad, ly), unkColor, "?/?");
                sdl->AddText(ImVec2(lx + contW * 0.78f - pad, ly), unkColor, "Inconnu");
            }
            else
            {
                sdl->AddText(ImVec2(lx, ly),
                    ImGui::GetColorU32(nameCol), entry.name.c_str());

                const char* catStr =
                    entry.category == MonsterCategory::BOSS      ? "BOSS"     :
                    entry.category == MonsterCategory::MINI_BOSS ? "MINIBOSS" : "NORMAL";
                sdl->AddText(ImVec2(lx + contW * 0.22f - pad, ly),
                    ImGui::GetColorU32(nameCol), catStr);

                char hpBuf[16], atkBuf[16], defBuf[16], mercBuf[16];
                snprintf(hpBuf,   sizeof(hpBuf),   "%.0f",  entry.hp);
                snprintf(atkBuf,  sizeof(atkBuf),  "%.0f",  entry.baseDommage);
                snprintf(defBuf,  sizeof(defBuf),  "%.0f",  entry.baseDefense);
                snprintf(mercBuf, sizeof(mercBuf), "0/%d",  entry.mercyGoal);

                ImU32 statColor = ImGui::GetColorU32(ImVec4(0.75f, 0.75f, 0.75f, 1.f));
                sdl->AddText(ImVec2(lx + contW * 0.34f - pad, ly), statColor, hpBuf);
                sdl->AddText(ImVec2(lx + contW * 0.44f - pad, ly), statColor, atkBuf);
                sdl->AddText(ImVec2(lx + contW * 0.54f - pad, ly), statColor, defBuf);
                sdl->AddText(ImVec2(lx + contW * 0.64f - pad, ly), statColor, mercBuf);

                char statusBuf[32] = "Rencontre";
                ImVec4 statusCol(0.5f, 0.5f, 0.5f, 1.f);
                if      (seen->seenKilled && seen->seenSpared)
                    { snprintf(statusBuf, sizeof(statusBuf), "Tue + Epargne");
                      statusCol = {0.9f, 0.75f, 0.2f, 1.f}; }
                else if (seen->seenKilled)
                    { snprintf(statusBuf, sizeof(statusBuf), "Tue");
                      statusCol = {0.9f, 0.3f,  0.3f, 1.f}; }
                else if (seen->seenSpared)
                    { snprintf(statusBuf, sizeof(statusBuf), "Epargne");
                      statusCol = {0.3f, 0.85f, 0.5f, 1.f}; }
                sdl->AddText(ImVec2(lx + contW * 0.78f - pad, ly),
                    ImGui::GetColorU32(statusCol), statusBuf);
            }

            ImGui::Dummy(ImVec2(contW - pad * 2.f, 22.f));
        }

        if (game.allMonsters.empty())
            ImGui::TextDisabled("Aucun monstre charge — verifiez monsters.csv");

        ImGui::EndChild();
        ImGui::EndTabItem();
    }

    // =========================================================================
    //  ONGLET 3 — STATS GLOBALES
    // =========================================================================
    if (ImGui::BeginTabItem("Stats globales"))
    {
        float tabY  = contY + 60.f;
        float col1  = contX + pad;
        float col2  = contX + contW * 0.45f;
        float rowH  = 28.f;

        auto gline = [&](const char* label, const char* val, float cx, float& y)
        {
            char buf[96];
            snprintf(buf, sizeof(buf), "%-26s %s", label, val);
            dl->AddText(ImVec2(cx, y),
                ImGui::GetColorU32(ImVec4(0.9f, 0.9f, 0.9f, 1.f)), buf);
            y += rowH;
        };
        auto glineI = [&](const char* label, int val, float cx, float& y)
        {
            char tmp[32]; snprintf(tmp, sizeof(tmp), "%d", val);
            gline(label, tmp, cx, y);
        };

        // ── Colonne gauche ─────────────────────────────────────
        dl->AddText(ImVec2(col1, tabY),
            ImGui::GetColorU32(ImVec4(0.6f, 0.85f, 1.f, 1.f)),
            "=== GENERAL ===");
        tabY += rowH;

        float y1 = tabY;
        glineI("Runs joues",          game.globalStats.nbRuns,        col1, y1);
        glineI("Kills totaux",        game.globalStats.nbTotalKills,  col1, y1);
        glineI("Epargnes totaux",     game.globalStats.nbTotalSpared, col1, y1);

        // Ratio kill/spare
        int totalMobs = game.globalStats.nbTotalKills + game.globalStats.nbTotalSpared;
        if (totalMobs > 0)
        {
            char ratioBuf[32];
            snprintf(ratioBuf, sizeof(ratioBuf), "%.0f%%",
                     100.f * game.globalStats.nbTotalKills / totalMobs);
            gline("Taux de kill", ratioBuf, col1, y1);
        }

        y1 += 8.f;
        dl->AddLine(ImVec2(col1, y1), ImVec2(col1 + contW * 0.38f, y1),
            ImGui::GetColorU32(ImVec4(0.3f, 0.3f, 0.3f, 0.5f)));
        y1 += 12.f;

        glineI("Fins Conquete",    game.globalStats.nbConquete,   col1, y1);
        glineI("Fins Redemption",  game.globalStats.nbRedemption, col1, y1);
        glineI("Fins Equilibre",   game.globalStats.nbEquilibre,  col1, y1);

        // Morts = runs - (conquete + redemption + equilibre)
        int morts = game.globalStats.nbRuns
                  - game.globalStats.nbConquete
                  - game.globalStats.nbRedemption
                  - game.globalStats.nbEquilibre;
        glineI("Defaites",         morts, col1, y1);

        // ── Colonne droite ─────────────────────────────────────
        float y2 = tabY;
        dl->AddText(ImVec2(col2, contY + 60.f),
            ImGui::GetColorU32(ImVec4(1.f, 0.75f, 0.35f, 1.f)),
            "=== RECORDS ===");
        y2 += rowH;

        // Records calculés depuis l'historique
        if (!game.runHistory.empty())
        {
            int maxLevel = 0, maxGold = 0, maxDmg = 0, maxTurns = 0;
            for (const auto& r : game.runHistory)
            {
                if (r.level      > maxLevel) maxLevel = r.level;
                if (r.gold       > maxGold)  maxGold  = r.gold;
                if (r.dmgDealt   > maxDmg)   maxDmg   = r.dmgDealt;
                if (r.turnsPlayed > maxTurns) maxTurns = r.turnsPlayed;
            }
            glineI("Niveau max atteint",  maxLevel, col2, y2);
            glineI("Or max accumule",     maxGold,  col2, y2);
            glineI("Degats max infliges", maxDmg,   col2, y2);
            glineI("Run la plus longue",  maxTurns, col2, y2);

            // Run actuelle
            y2 += 8.f;
            dl->AddLine(ImVec2(col2, y2), ImVec2(col2 + contW * 0.45f, y2),
                ImGui::GetColorU32(ImVec4(0.3f, 0.3f, 0.3f, 0.5f)));
            y2 += 12.f;

            char seedBuf[48];
            snprintf(seedBuf, sizeof(seedBuf), "%u", game.globalStats.lastSeed);
            gline("Derniere seed", seedBuf, col2, y2);
        }
        else
        {
            dl->AddText(ImVec2(col2, y2),
                ImGui::GetColorU32(ImVec4(0.45f, 0.45f, 0.45f, 1.f)),
                "Aucun run termine");
        }

        ImGui::EndTabItem();
    }

    // =========================================================================
    //  ONGLET 4 — HISTORIQUE DES RUNS (tous les runs, scrollable)
    // =========================================================================
    if (ImGui::BeginTabItem("Historique"))
    {
        float rowH = 22.f;
        float cx   = 0.f; // relatif au BeginChild

        // Colonnes relatives à la largeur du child
        float childW = contW - pad * 2.f;
        float cRun  = 0.f;
        float cEnd  = childW * 0.12f;
        float cKill = childW * 0.27f;
        float cSpar = childW * 0.37f;
        float cLvl  = childW * 0.47f;
        float cGold = childW * 0.56f;
        float cDmg  = childW * 0.66f;
        float cTurn = childW * 0.76f;
        float cSeed = childW * 0.86f;

        if (game.runHistory.empty())
        {
            ImGui::SetCursorPosY(contH * 0.4f);
            ImGui::TextDisabled("Aucun run termine pour l'instant.");
        }
        else
        {
            // En-tête fixe — forcer le curseur dans le panneau
            ImGui::SetCursorPosX(contX + pad);
            ImDrawList* hdl = ImGui::GetWindowDrawList();
            ImVec2 hPos = ImGui::GetCursorScreenPos();
            float  hy   = hPos.y;            ImU32 hdrCol = ImGui::GetColorU32(ImVec4(0.6f, 0.6f, 0.6f, 1.f));
            hdl->AddText(ImVec2(hPos.x + cRun,  hy), hdrCol, "Run");
            hdl->AddText(ImVec2(hPos.x + cEnd,  hy), hdrCol, "Fin");
            hdl->AddText(ImVec2(hPos.x + cKill, hy), hdrCol, "Tues");
            hdl->AddText(ImVec2(hPos.x + cSpar, hy), hdrCol, "Eparges");
            hdl->AddText(ImVec2(hPos.x + cLvl,  hy), hdrCol, "Niv.");
            hdl->AddText(ImVec2(hPos.x + cGold, hy), hdrCol, "Or");
            hdl->AddText(ImVec2(hPos.x + cDmg,  hy), hdrCol, "Degats");
            hdl->AddText(ImVec2(hPos.x + cTurn, hy), hdrCol, "Tours");
            hdl->AddText(ImVec2(hPos.x + cSeed, hy), hdrCol, "Seed");
            hdl->AddLine(ImVec2(hPos.x, hy + rowH + 2.f),
                         ImVec2(hPos.x + childW, hy + rowH + 2.f),
                         ImGui::GetColorU32(ImVec4(0.35f, 0.35f, 0.45f, 0.8f)));

            // Zone scrollable — positionnée dans le panneau
            ImGui::Dummy(ImVec2(childW, rowH + 10.f));
            ImGui::SetCursorPosX(contX + pad);
            float scrollH = contH - 120.f;
            ImGui::BeginChild("##history_scroll",
                              ImVec2(childW, scrollH), false);

            for (const auto& r : game.runHistory)
            {
                ImVec4 endCol =
                    r.ending == RunEnding::CONQUETE   ? ImVec4(1.f,  0.35f, 0.35f, 1.f) :
                    r.ending == RunEnding::REDEMPTION ? ImVec4(0.35f,0.75f, 1.f,   1.f) :
                    r.ending == RunEnding::MORT       ? ImVec4(0.5f, 0.5f,  0.5f,  1.f) :
                                                        ImVec4(1.f,  0.80f, 0.25f, 1.f);
                const char* endStr =
                    r.ending == RunEnding::CONQUETE   ? "Conquete"   :
                    r.ending == RunEnding::REDEMPTION ? "Redemption" :
                    r.ending == RunEnding::MORT       ? "Mort"       :
                                                        "Equilibre";

                ImDrawList* sdl = ImGui::GetWindowDrawList();
                ImVec2 cur = ImGui::GetCursorScreenPos();
                float  lx  = cur.x;
                float  ly  = cur.y;
                ImU32 rowCol = ImGui::GetColorU32(ImVec4(0.85f, 0.85f, 0.85f, 1.f));
                char buf[32];

                snprintf(buf, sizeof(buf), "#%d", r.runNumber);
                sdl->AddText(ImVec2(lx + cRun,  ly), rowCol, buf);
                sdl->AddText(ImVec2(lx + cEnd,  ly),
                             ImGui::GetColorU32(endCol), endStr);
                snprintf(buf, sizeof(buf), "%d", r.nbKilled);
                sdl->AddText(ImVec2(lx + cKill, ly), rowCol, buf);
                snprintf(buf, sizeof(buf), "%d", r.nbSpared);
                sdl->AddText(ImVec2(lx + cSpar, ly), rowCol, buf);
                snprintf(buf, sizeof(buf), "%d", r.level);
                sdl->AddText(ImVec2(lx + cLvl,  ly), rowCol, buf);
                snprintf(buf, sizeof(buf), "%d", r.gold);
                sdl->AddText(ImVec2(lx + cGold, ly), rowCol, buf);
                snprintf(buf, sizeof(buf), "%d", r.dmgDealt);
                sdl->AddText(ImVec2(lx + cDmg,  ly), rowCol, buf);
                snprintf(buf, sizeof(buf), "%d", r.turnsPlayed);
                sdl->AddText(ImVec2(lx + cTurn, ly), rowCol, buf);
                snprintf(buf, sizeof(buf), "%u", r.seed);
                sdl->AddText(ImVec2(lx + cSeed, ly),
                             ImGui::GetColorU32(ImVec4(0.45f,0.45f,0.45f,1.f)), buf);

                ImGui::Dummy(ImVec2(childW, rowH + 4.f));
            }

            ImGui::EndChild();
        }

        ImGui::EndTabItem();
    }

        ImGui::EndTabBar();

    float btnW = winW / 4.f;
    float btnH = winH / 20.f;
    ImGui::SetCursorPos(ImVec2(winW * 0.5f - btnW * 0.5f,
                               contY + contH + pad * 1.5f));
    if (actionButton("Retour", ImVec2(btnW, btnH)))
    {
        playButtonSound();
        startFade(GameScreen::MENU);
    }

    ImGui::End();
}


void Interface::renderClassSelect(Game& game)
{
    if (!beginFullscreen("##classselect")) { ImGui::End(); return; }

    if (!bgFrames.empty()) {
        ImGui::SetCursorPos({0, 0});
        ImGui::Image(bgFrames[currentFrame]);
    }

    float winW = ImGui::GetWindowWidth();
    float winH = ImGui::GetWindowHeight();

    float cardW  = winW / 5.f;
    float cardH  = winH * 0.55f;
    float gap    = winW / 20.f;
    float totalW = NUM_CLASSES * cardW + (NUM_CLASSES - 1) * gap;
    float startX = (winW - totalW) * 0.5f;
    float startY = (winH - cardH) * 0.5f;

    for (int i = 0; i < NUM_CLASSES; i++)
    {
        ImGui::SetCursorPos(ImVec2(startX + i * (cardW + gap), startY));
        if (classCard(i, ImVec2(cardW, cardH), selectedClass == i))
            selectedClass = i;
    }

    // Saisie nom + seed
    float seedY = startY + cardH + 20.f;
    float inputW = 200.f;
    float totalInputW = inputW + 20.f + inputW; // nom + gap + seed
    float inputStartX = (winW - totalInputW) * 0.5f;

    ImGui::PushStyleColor(ImGuiCol_FrameBg,        ImVec4(0.10f, 0.10f, 0.10f, 0.90f));
    ImGui::PushStyleColor(ImGuiCol_FrameBgHovered, ImVec4(0.18f, 0.18f, 0.18f, 0.90f));
    ImGui::PushStyleColor(ImGuiCol_FrameBgActive,  ImVec4(0.22f, 0.18f, 0.08f, 1.00f));

    ImGui::SetCursorPos(ImVec2(inputStartX, seedY));
    ImGui::TextDisabled("Nom :");
    ImGui::SameLine();
    ImGui::SetNextItemWidth(inputW);
    ImGui::InputText("##playername", nameInput, sizeof(nameInput));

    ImGui::SameLine(0.f, 30.f);
    ImGui::TextDisabled("Seed (optionnel) :");
    ImGui::SameLine();
    ImGui::SetNextItemWidth(inputW);
    ImGui::InputText("##seed", seedInput, sizeof(seedInput),
                     ImGuiInputTextFlags_CharsDecimal);

    ImGui::PopStyleColor(3);

    if (selectedClass >= 0)
    {
        float btnW = winW / 5.f;
        float btnH = winH / 18.f;
        ImGui::SetCursorPos(ImVec2((winW - btnW) * 0.5f,
                                   winH - btnH - winH / 12.f));
        if (actionButton("Confirmer", ImVec2(btnW, btnH)))
        {
            playButtonSound();
            unsigned int userSeed = 0;
            if (seedInput[0] != '\0')
                userSeed = (unsigned int)std::stoul(seedInput);

            // Nom : "Tav" par défaut si vide
            const char* playerName = (nameInput[0] != '\0') ? nameInput : "Tav";

            PowerClass pc = static_cast<PowerClass>(selectedClass);
            game.startRun(playerName, pc, userSeed);
            // Un nouveau run commence toujours sur l'écran intermédiaire
            game.screen = GameScreen::CLASS_SELECT;
            startFade(GameScreen::INTERMEDIATE);
        }
    }

    ImGui::End();
}

// ============================================================
//  RENDU — COMBAT
// ============================================================

void Interface::renderCombat(Game& game)
{
    // Guard : si pas de monstre, afficher un message plutôt qu'un écran noir
    if (!game.currentPlayer.has_value() || !game.currentMonster.has_value())
    {
        if (!beginFullscreen("##combat_wait")) { ImGui::End(); return; }
        if (!bgFrames.empty()) { ImGui::SetCursorPos({0,0}); ImGui::Image(bgFrames[currentFrame]); }

        float winW = ImGui::GetWindowWidth();
        float winH = ImGui::GetWindowHeight();
        ImGui::SetCursorPos(ImVec2(winW * 0.5f - 150.f, winH * 0.5f));
        ImGui::TextDisabled("Aucun monstre disponible — verifiez monsters.csv");

        float btnW = winW / 4.f;
        float btnH = winH / 20.f;
        ImGui::SetCursorPos(ImVec2(winW * 0.5f - btnW * 0.5f, winH * 0.5f + 60.f));
        if (actionButton("Retour au menu", ImVec2(btnW, btnH)))
            game.screen = GameScreen::MENU;

        ImGui::End();
        return;
    }

    Player&  player  = game.currentPlayer.value();
    Monster& monster = game.currentMonster.value();

    if (!beginFullscreen("##combat")) { ImGui::End(); return; }

    if (!bgFrames.empty()) {
        ImGui::SetCursorPos({0, 0});
        ImGui::Image(bgFrames[currentFrame]);
    }

    float winW = ImGui::GetWindowWidth();
    float winH = ImGui::GetWindowHeight();
    ImDrawList* dl = ImGui::GetWindowDrawList();

    float pad  = 24.f;
    float barW = winW * 0.28f;
    float barH = 20.f;

    bool isPlayerTurn = (game.combatPhase == CombatPhase::PLAYER_TURN);

    // ── Indicateur combat n/10 (centré en haut) ───────────────
    {
        char combatBuf[32];
        snprintf(combatBuf, sizeof(combatBuf), "Combat  %d / 10", game.combatNumber);
        ImVec2 wPos = ImGui::GetWindowPos();
        ImVec2 tSz  = ImGui::CalcTextSize(combatBuf);
        float  indW = tSz.x + 24.f;
        float  indH = tSz.y + 10.f;
        float  indX = wPos.x + (winW - indW) * 0.5f;
        float  indY = wPos.y + 8.f;

        dl->AddRectFilled(ImVec2(indX, indY),
                          ImVec2(indX + indW, indY + indH),
                          ImGui::GetColorU32(ImVec4(0.05f, 0.05f, 0.05f, 0.80f)), 6.f);
        dl->AddRect(ImVec2(indX, indY),
                    ImVec2(indX + indW, indY + indH),
                    ImGui::GetColorU32(ImVec4(0.55f, 0.45f, 0.15f, 0.9f)), 6.f);
        dl->AddText(ImVec2(indX + 12.f, indY + 5.f),
                    ImGui::GetColorU32(ImVec4(0.95f, 0.80f, 0.35f, 1.f)), combatBuf);
    }

    // ── Bouton Pause (haut gauche) ────────────────────────────
    ImGui::SetCursorPos(ImVec2(10.f, 10.f));
    if (ImGui::Button("Pause##pause_btn", ImVec2(80.f, 34.f)))
    {
        playButtonSound();
        paused = true;
    }

    // ── Panneau monstre (haut droite) ────────────────────────
    float mPanelX = winW - pad - winW * 0.42f;
    float mPanelY = winH * 0.06f;
    float mPanelW = winW * 0.42f;
    float mPanelH = winH * 0.30f;

    drawPanel(dl, mPanelX, mPanelY, mPanelW, mPanelH,
              ImVec4(0.5f, 0.2f, 0.2f, 0.8f));

    ImGui::SetCursorPos(ImVec2(mPanelX + pad, mPanelY + pad));
    ImGui::Text("%s", monster.name.c_str());

    ImGui::SetCursorPos(ImVec2(mPanelX + pad, mPanelY + pad + 30.f));
    drawBar(dl, ImGui::GetCursorScreenPos(), barW, barH,
            monster.hp, monster.hpMax, ImVec4(0.85f, 0.2f, 0.2f, 1.f), "HP");
    ImGui::Dummy(ImVec2(barW, barH + 6.f));

    ImGui::SetCursorPos(ImVec2(mPanelX + pad, mPanelY + pad + 62.f));
    drawBar(dl, ImGui::GetCursorScreenPos(), barW, barH,
            (float)monster.mercy, (float)monster.mercyGoal,
            ImVec4(0.35f, 0.75f, 0.95f, 1.f), "Mercy");
    ImGui::Dummy(ImVec2(barW, barH + 6.f));

    {
        ImVec2 wPos = ImGui::GetWindowPos();
        ImVec2 badgeStart = ImVec2(wPos.x + mPanelX + pad,
                                   wPos.y + mPanelY + pad + 96.f);
        if (monster.activeEffects.empty())
        {
            ImGui::SetCursorPos(ImVec2(mPanelX + pad, mPanelY + pad + 96.f));
            ImGui::TextDisabled("Aucun effet");
        }
        else
            drawEffectBadges(dl, monster.activeEffects, badgeStart, barW);
    }

    // ── Log (centre) ─────────────────────────────────────────
    ImGui::SetCursorPos(ImVec2(winW * 0.28f, winH * 0.40f));
    ImGui::PushStyleColor(ImGuiCol_ChildBg, ImVec4(0.04f, 0.04f, 0.04f, 0.82f));
    ImGui::BeginChild("##log", ImVec2(winW * 0.44f, winH * 0.14f), true);

    for (auto it = game.combatLog.rbegin(); it != game.combatLog.rend(); ++it)
    {
        const std::string& msg = *it;
        ImVec4 col = ImVec4(0.85f, 0.85f, 0.85f, 1.f); // défaut gris clair

        if (msg.find("degats") != std::string::npos ||
            msg.find("prend")  != std::string::npos)
            col = ImVec4(0.95f, 0.45f, 0.35f, 1.f); // rouge — dégâts

        else if (msg.find("recup") != std::string::npos ||
                 msg.find("regen") != std::string::npos ||
                 msg.find("HP")    != std::string::npos)
            col = ImVec4(0.35f, 0.90f, 0.45f, 1.f); // vert — soin

        else if (msg.find("mercy") != std::string::npos ||
                 msg.find("Mercy") != std::string::npos ||
                 msg.find("epargne") != std::string::npos)
            col = ImVec4(0.40f, 0.80f, 1.0f, 1.f); // cyan — mercy

        else if (msg.find("niveau") != std::string::npos ||
                 msg.find("Niveau") != std::string::npos)
            col = ImVec4(1.0f, 0.85f, 0.25f, 1.f); // doré — level up

        else if (msg.find(">>") != std::string::npos ||
                 msg.find("!!") != std::string::npos)
            col = ImVec4(0.95f, 0.75f, 0.20f, 1.f); // ambre — événement

        else if (msg.find("utilise") != std::string::npos ||
                 msg.find("utilise") != std::string::npos)
            col = ImVec4(0.70f, 0.70f, 0.70f, 1.f); // gris — action neutre

        ImGui::PushStyleColor(ImGuiCol_Text, col);
        ImGui::TextWrapped("%s", msg.c_str());
        ImGui::PopStyleColor();
    }

    ImGui::EndChild();
    ImGui::PopStyleColor();

    // ── Panneau joueur (bas gauche) ──────────────────────────
    float jPanelX = pad;
    float jPanelY = winH * 0.57f;
    float jPanelW = winW * 0.24f;
    float jPanelH = winH * 0.34f;

    drawPanel(dl, jPanelX, jPanelY, jPanelW, jPanelH,
              ImVec4(0.2f, 0.5f, 0.2f, 0.8f));

    ImGui::SetCursorPos(ImVec2(jPanelX + pad, jPanelY + pad));
    ImGui::Text("%s", player.name.c_str());
    ImGui::SameLine(0.f, 10.f);

    // Niveau et or sur la même ligne
    {
        ImVec2 wPos = ImGui::GetWindowPos();
        ImVec2 cPos = ImGui::GetCursorScreenPos();
        char lvlBuf[32];
        snprintf(lvlBuf, sizeof(lvlBuf), "Niv.%d", player.level);
        dl->AddText(cPos, ImGui::GetColorU32(ImVec4(0.9f, 0.75f, 0.2f, 1.f)), lvlBuf);
        char goldBuf[16];
        snprintf(goldBuf, sizeof(goldBuf), "%d Or", player.gold);
        ImVec2 gSz = ImGui::CalcTextSize(goldBuf);
        dl->AddText(ImVec2(wPos.x + jPanelX + jPanelW - pad - gSz.x, cPos.y),
                    ImGui::GetColorU32(ImVec4(0.95f, 0.80f, 0.2f, 1.f)), goldBuf);
    }

    ImGui::SetCursorPos(ImVec2(jPanelX + pad, jPanelY + pad + 30.f));
    drawBar(dl, ImGui::GetCursorScreenPos(), jPanelW - 2.f * pad, barH,
            player.hp, player.hpMax, ImVec4(0.2f, 0.8f, 0.3f, 1.f), "HP");
    ImGui::Dummy(ImVec2(jPanelW - 2.f * pad, barH + 6.f));

    // Barre XP
    ImGui::SetCursorPos(ImVec2(jPanelX + pad, jPanelY + pad + 62.f));
    drawBar(dl, ImGui::GetCursorScreenPos(), jPanelW - 2.f * pad, barH - 4.f,
            (float)player.xp, 100.f, ImVec4(0.6f, 0.4f, 0.9f, 1.f), "XP");
    ImGui::Dummy(ImVec2(jPanelW - 2.f * pad, barH + 2.f));

    // Statuts — décalés sous la barre XP
    {
        ImVec2 wPos = ImGui::GetWindowPos();
        ImVec2 badgeStart = ImVec2(wPos.x + jPanelX + pad,
                                   wPos.y + jPanelY + pad + 96.f);
        if (player.activeEffects.empty())
        {
            ImGui::SetCursorPos(ImVec2(jPanelX + pad, jPanelY + pad + 96.f));
            ImGui::TextDisabled("Aucun effet");
        }
        else
            drawEffectBadges(dl, player.activeEffects, badgeStart,
                             jPanelW - 2.f * pad);
    }

    // ── Panneau actions (bas droite) ─────────────────────────
    float aPanelX = winW * 0.30f;
    float aPanelY = winH * 0.54f;
    float aPanelW = winW * 0.68f - pad;
    float aPanelH = winH * 0.43f;
    float btnW    = winW / 10.f;
    float btnH    = winH / 20.f;  // compact pour tenir 4 rangées
    float rowGap  = 6.f;

    drawPanel(dl, aPanelX, aPanelY, aPanelW, aPanelH,
              ImVec4(0.6f, 0.5f, 0.1f, 0.8f));

    float rowY = aPanelY + pad;

    // ── Base ─────────────────────────────────────────────────
    ImGui::SetCursorPos(ImVec2(aPanelX + pad, rowY));
    ImGui::TextDisabled("Base");
    rowY += 18.f;
    ImGui::SetCursorPos(ImVec2(aPanelX + pad, rowY));

    if (actionButton("Attaquer", ImVec2(btnW, btnH), !isPlayerTurn,
        "Inflige des degats a l'ennemi basés sur votre attaque de base."))
    {
        float hpBefore = monster.hp;
        Action atk(0, "Attaque", "", ActionType::DOMMAGE, player.baseDommage, false);
        atk.apply(&monster, &game.combatLog);
        int dmg = (int)(hpBefore - monster.hp);
        if (dmg > 0) game.combatStats.dmgDealt += dmg;
        game.combatPhase = CombatPhase::MONSTER_TURN;
        game.checkCombatEnd();
    }
    ImGui::SameLine(0.f, 8.f);
    if (actionButton("Defendre", ImVec2(btnW, btnH), !isPlayerTurn,
        "Augmente votre defense de 3 pour ce tour."))
    {
        Action def(0, "Defense", "", ActionType::BUFF_DEF, 3.f, true);
        def.apply(&player, &game.combatLog);
        game.combatPhase = CombatPhase::MONSTER_TURN;
        game.checkCombatEnd();
    }
    ImGui::SameLine(0.f, 8.f);
    if (actionButton("Apaisement", ImVec2(btnW, btnH), !isPlayerTurn,
        "Augmente la mercy de l'ennemi de 5. Voie pacifique."))
    {
        int mercyBefore = monster.mercy;
        Action apaiser(60, "Apaisement", "", ActionType::MERCY_DOMMAGE, 5.f, false);
        apaiser.apply(&monster, &game.combatLog);
        game.combatStats.mercyDealt += monster.mercy - mercyBefore;
        game.combatPhase = CombatPhase::MONSTER_TURN;
        game.checkCombatEnd();
    }
    rowY += btnH + rowGap;

    // ── Equipement ───────────────────────────────────────────
    ImGui::SetCursorPos(ImVec2(aPanelX + pad, rowY));
    ImGui::TextDisabled("Equipement");
    rowY += 18.f;
    ImGui::SetCursorPos(ImVec2(aPanelX + pad, rowY));
    if (player.actions.empty())
        ImGui::TextDisabled("  Aucun equipement");
    else
        for (auto& act : player.actions)
        {
            Entity* target = act.selfTarget
                ? static_cast<Entity*>(&player)
                : static_cast<Entity*>(&monster);
            if (actionButton(act.name.c_str(), ImVec2(btnW, btnH), !isPlayerTurn,
                              act.description.empty() ? nullptr : act.description.c_str()))
            {
                act.apply(target, &game.combatLog);
                game.combatPhase = CombatPhase::MONSTER_TURN;
                game.checkCombatEnd();
            }
            ImGui::SameLine(0.f, 8.f);
        }
    rowY += btnH + rowGap;

    // ── Consommables ─────────────────────────────────────────
    ImGui::SetCursorPos(ImVec2(aPanelX + pad, rowY));
    ImGui::TextDisabled("Consommables");
    rowY += 18.f;
    ImGui::SetCursorPos(ImVec2(aPanelX + pad, rowY));

    bool hasConsumable = false;
    for (int i = 0; i < (int)player.inventory.slots.size(); i++)
    {
        InventorySlot& slot = player.inventory.slots[i];
        if (!slot.item || slot.item->type != ItemType::CONSUMABLE) continue;

        hasConsumable = true;
        char label[64];
        snprintf(label, sizeof(label), "%s (%d)##conso%d",
                 slot.item->name.c_str(), slot.quantity, i);

        const char* consoTip = slot.item ? slot.item->description.c_str() : nullptr;
        if (actionButton(label, ImVec2(btnW * 1.4f, btnH), !isPlayerTurn, consoTip))
        {
            player.inventory.use(i, &player, &game.combatLog);
            game.combatPhase = CombatPhase::MONSTER_TURN;
            game.checkCombatEnd();
            break;
        }
        ImGui::SameLine(0.f, 8.f);
    }
    if (!hasConsumable)
        ImGui::TextDisabled("  Aucun consommable");
    rowY += btnH + rowGap;

    // ── Pouvoir de classe ─────────────────────────────────────
    ImGui::SetCursorPos(ImVec2(aPanelX + pad, rowY));
    ImGui::TextDisabled("Pouvoir");
    rowY += 18.f;
    ImGui::SetCursorPos(ImVec2(aPanelX + pad, rowY));

    if (player.powerActions.empty())
    {
        ImGui::TextDisabled("  Aucun pouvoir");
    }
    else
    {
        for (int pi = 0; pi < (int)player.powerActions.size(); pi++)
        {
            Action* act = player.powerActions[pi];
            if (!act) continue;
            // ID unique par index pour éviter les collisions ImGui
            char powerLabel[64];
            if (player.usePower)
                snprintf(powerLabel, sizeof(powerLabel), "%s##pow%d", act->name.c_str(), pi);
            else
                snprintf(powerLabel, sizeof(powerLabel), "[ Utilise ]##pow%d", pi);

            const char* powerTip = (player.usePower && act)
                ? act->description.c_str() : nullptr;
            if (actionButton(powerLabel, ImVec2(btnW * 1.4f, btnH),
                             !isPlayerTurn || !player.usePower, powerTip))
            {
                act->apply(&monster, &game.combatLog);
                player.usePower  = false;
                game.combatPhase = CombatPhase::MONSTER_TURN;
                game.checkCombatEnd();
            }
            ImGui::SameLine(0.f, 8.f);
        }
    }

    // ── Tour monstre ─────────────────────────────────────────
    if (game.combatPhase == CombatPhase::MONSTER_TURN)
    {
        float hpBefore = player.hp;
        monster.playTurn(&player, &game.combatLog);
        monster.tickEffects(&game.combatLog);
        player.tickEffects(&game.combatLog);
        game.combatPhase = CombatPhase::PLAYER_TURN;
        game.checkCombatEnd();

        // Stats : dégâts reçus ce tour
        float dmgReceived = hpBefore - player.hp;
        if (dmgReceived > 0)
            game.combatStats.dmgReceived += (int)dmgReceived;
        game.combatStats.turnsPlayed++;
    }

    ImGui::End();

    // Popup fin de combat — fenêtre séparée pour éviter les conflits draw list
    if (game.combatPhase == CombatPhase::END)
        renderCombatEnd(game);
}

// ============================================================
//  RENDU — FIN DE COMBAT
// ============================================================

void Interface::renderCombatEnd(Game& game)
{
    Monster& monster = game.currentMonster.value();
    Player&  player  = game.currentPlayer.value();

    float scrW = (float)window.getSize().x;
    float scrH = (float)window.getSize().y;

    // Fenêtre plein écran avec fond sombre — contient overlay + popup
    ImGui::SetNextWindowPos(ImVec2(0, 0));
    ImGui::SetNextWindowSize(ImVec2(scrW, scrH));
    ImGui::SetNextWindowBgAlpha(1.0f);
    ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.f, 0.f, 0.f, 0.72f));
    ImGuiWindowFlags flags = ImGuiWindowFlags_NoDecoration
                           | ImGuiWindowFlags_NoMove
                           | ImGuiWindowFlags_NoSavedSettings
                           | ImGuiWindowFlags_NoNav;

    if (!ImGui::Begin("##combat_overlay", nullptr, flags))
    {
        ImGui::PopStyleColor();
        ImGui::End(); return;
    }

    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImVec2     wPos = ImGui::GetWindowPos();
    float      W    = scrW;
    float      H    = scrH;

    float panelW = W * 0.42f;
    float panelH = H * 0.44f;
    float absPX  = wPos.x + (W - panelW) * 0.5f;
    float absPY  = wPos.y + (H - panelH) * 0.5f;
    float panelX = (W - panelW) * 0.5f;  // local pour SetCursorPos
    float panelY = (H - panelH) * 0.5f;
    float btnW   = panelW * 0.50f;
    float btnH   = H / 16.f;

    bool isDefeat = (game.combatResult == CombatResult::DEFEAT);
    bool spared   = (game.combatResult == CombatResult::SPARED);

    ImVec4 borderCol = isDefeat ? ImVec4(0.7f, 0.1f, 0.1f, 1.f)
                     : spared   ? ImVec4(0.2f, 0.6f, 0.95f, 1.f)
                                : ImVec4(0.2f, 0.75f, 0.2f, 1.f);

    // Panneau
    dl->AddRectFilled(ImVec2(absPX, absPY),
                      ImVec2(absPX + panelW, absPY + panelH),
                      ImGui::GetColorU32(ImVec4(0.08f, 0.08f, 0.08f, 0.97f)), 10.f);
    dl->AddRect(ImVec2(absPX, absPY),
                ImVec2(absPX + panelW, absPY + panelH),
                ImGui::GetColorU32(borderCol), 10.f, 0, 2.f);

    auto centeredText = [&](const char* text, ImVec4 col, float relY)
    {
        ImVec2 sz = ImGui::CalcTextSize(text);
        dl->AddText(ImVec2(absPX + (panelW - sz.x) * 0.5f, absPY + relY),
                    ImGui::GetColorU32(col), text);
    };

    // ── DÉFAITE ───────────────────────────────────────────────────────────────
    if (isDefeat)
    {
        centeredText("GAME OVER",
                     ImVec4(1.f, 0.2f, 0.2f, 1.f), panelH * 0.18f);
        centeredText("Votre aventure s'arrete ici.",
                     ImVec4(0.7f, 0.7f, 0.7f, 1.f), panelH * 0.38f);

        ImGui::SetCursorPos(ImVec2(panelX + (panelW - btnW) * 0.5f,
                                   panelY + panelH * 0.62f));
        if (actionButton("Menu principal##defeat", ImVec2(btnW, btnH)))
        {
            playButtonSound();
            game.endRun(true); // lastRunStats sauvegardés avant reset
            selectedClass = -1;
            game.screen = GameScreen::END_RUN; // direct, sans fade
        }
        ImGui::PopStyleColor();
        ImGui::End();
        return;
    }

    // ── VICTOIRE / ÉPARGNÉ ────────────────────────────────────────────────────
    const char* title    = spared ? "MONSTRE EPARGNE" : "VICTOIRE !";
    ImVec4      titleCol = spared ? ImVec4(0.4f, 0.85f, 1.f, 1.f)
                                  : ImVec4(0.3f, 1.f,   0.3f, 1.f);
    centeredText(title, titleCol, panelH * 0.10f);

    float sepAbsY = absPY + panelH * 0.24f;
    dl->AddLine(ImVec2(absPX + 20.f, sepAbsY),
                ImVec2(absPX + panelW - 20.f, sepAbsY),
                ImGui::GetColorU32(ImVec4(0.4f, 0.4f, 0.4f, 0.5f)));

    static bool rewardsApplied = false;
    if (!rewardsApplied)
    {
        game.applyRewards();
        game.buildIntermediateScreen();
        rewardsApplied = true;
    }

    float lineH = 28.f;
    float ry    = panelH * 0.30f;

    if (!spared)
    {
        char xpBuf[32], goldBuf[32];
        snprintf(xpBuf,   sizeof(xpBuf),   "+ %d XP",
                 (int)(monster.xpReward * monster.rewardScale));
        snprintf(goldBuf, sizeof(goldBuf),  "+ %d Or",
                 (int)(monster.goldReward * monster.rewardScale));
        centeredText(xpBuf,   ImVec4(0.5f, 0.9f, 0.5f,  1.f), ry);
        centeredText(goldBuf, ImVec4(0.95f, 0.80f, 0.2f, 1.f), ry + lineH);
    }
    else
    {
        char xpBuf[48];
        snprintf(xpBuf, sizeof(xpBuf), "+ %d XP  (epargne)",
                 (int)(monster.xpReward * monster.rewardScale));
        centeredText(xpBuf, ImVec4(0.5f, 0.9f, 0.5f, 1.f), ry);
        centeredText("La pitie a son propre chemin.",
                     ImVec4(0.6f, 0.8f, 1.f, 1.f), ry + lineH);
    }

    char lvlBuf[32];
    snprintf(lvlBuf, sizeof(lvlBuf), "Niveau %d", player.level);
    centeredText(lvlBuf, ImVec4(0.75f, 0.75f, 0.75f, 1.f), ry + lineH * 2.5f);

    ImGui::SetCursorPos(ImVec2(panelX + (panelW - btnW) * 0.5f,
                               panelY + panelH * 0.74f));
    if (actionButton("Continuer##victory", ImVec2(btnW, btnH)))
    {
        playButtonSound();
        rewardsApplied = false;

        if (game.isLastCombat())
        {
            game.endRun();
        }
        else
        {
            game.combatNumber++;
            game.combatResult  = CombatResult::NONE;
            game.combatPhase   = CombatPhase::PLAYER_TURN;
            game.currentMonster.reset();
            game.combatLog.clear();
            game.pathChoices.clear();
            startFade(GameScreen::INTERMEDIATE);
        }
    }

    ImGui::PopStyleColor();
    ImGui::End();
}

// ============================================================
//  RENDU — ÉCRAN INTERMÉDIAIRE
// ============================================================

void Interface::renderIntermediate(Game& game)
{
    if (!game.currentPlayer.has_value()) return;
    Player& player = game.currentPlayer.value();

    if (!beginFullscreen("##inter")) { ImGui::End(); return; }

    if (!bgFrames.empty()) {
        ImGui::SetCursorPos({0, 0});
        ImGui::Image(bgFrames[currentFrame]);
    }

    // ── Bouton Pause (haut gauche) ────────────────────────────
    ImGui::SetCursorPos(ImVec2(10.f, 10.f));
    if (ImGui::Button("Pause##pause_inter", ImVec2(80.f, 34.f)))
    {
        playButtonSound();
        paused = true;
    }

    float winW = ImGui::GetWindowWidth();
    float winH = ImGui::GetWindowHeight();
    ImDrawList* dl = ImGui::GetWindowDrawList();

    float pad    = 14.f;
    float colW   = winW * 0.18f;
    float panelH = winH * 0.72f;
    float panelY = winH * 0.14f;
    float col1X  = winW * 0.01f;   // Loot
    float col2X  = winW * 0.21f;   // Équipement
    float col3X  = winW * 0.41f;   // Repos
    float col4X  = winW * 0.61f;   // Marchand
    float col5X  = winW * 0.81f;   // Chemin
    float btnW   = colW - 2.f * pad;
    float btnH   = winH / 18.f;

    // ── Loot ─────────────────────────────────────────────────
    drawPanel(dl, col1X, panelY, colW, panelH,
              ImVec4(0.8f, 0.65f, 0.1f, 0.8f));
    drawSectionTitle(dl, col1X, panelY, colW, "LOOT",
                     ImVec4(0.95f, 0.80f, 0.2f, 1.f));

    float itemY = panelY + pad * 2.5f;
    for (Item* item : game.lootPool)
    {
        dl->AddText(ImVec2(col1X + pad, itemY + 2.f),
            ImGui::GetColorU32(ImVec4(1.f, 1.f, 1.f, 1.f)),
            item->name.c_str());
        dl->AddText(ImVec2(col1X + pad + 38.f, itemY + 18.f),
            ImGui::GetColorU32(ImVec4(0.6f, 0.6f, 0.6f, 1.f)),
            item->description.c_str());
        itemY += 38.f;

        ImGui::SetCursorPos(ImVec2(col1X + pad, itemY));
        char pickLabel[64];
        snprintf(pickLabel, sizeof(pickLabel), "Prendre##%d", item->id);

        // Vérifier si on peut prendre (limite consommables)
        bool canTake = true;
        if (item->type == ItemType::CONSUMABLE &&
            player.consumableCount() >= Player::MAX_CONSUMABLES)
            canTake = false;

        if (actionButton(pickLabel, ImVec2(btnW, btnH), !canTake))
        {
            playButtonSound();
            if (item->type == ItemType::EQUIPPABLE)
            {
                if (item->slotType == EquipSlot::RING &&
                    player.equipment.firstFreeRingSlot() < 0)
                {
                    // Tous les slots bagues pleins → demander le choix
                    game.pendingRingChoice = true;
                    game.pendingRingItem   = item;
                }
                else
                {
                    player.equipItem(item, &game.combatLog);
                    player.inventory.add(item, 1, &game.combatLog);
                    game.lootPool.erase(
                        std::remove(game.lootPool.begin(),
                                    game.lootPool.end(), item),
                        game.lootPool.end());
                }
            }
            else
            {
                player.inventory.add(item, 1, &game.combatLog);
                game.lootPool.erase(
                    std::remove(game.lootPool.begin(),
                                game.lootPool.end(), item),
                    game.lootPool.end());
            }
            break;
        }
        if (!canTake)
        {
            dl->AddText(ImVec2(col1X + pad, itemY + btnH + 2.f),
                ImGui::GetColorU32(ImVec4(0.8f, 0.4f, 0.2f, 1.f)),
                "Consommables pleins (5/5)");
        }
        itemY += btnH + 18.f;
    }
    if (game.lootPool.empty())
    {
        ImGui::SetCursorPos(ImVec2(col1X + pad, panelY + panelH * 0.5f));
        ImGui::TextDisabled("Rien de plus");
    }

    // ── Équipement ────────────────────────────────────────────
    drawPanel(dl, col2X, panelY, colW, panelH,
              ImVec4(0.3f, 0.5f, 0.7f, 0.8f));
    drawSectionTitle(dl, col2X, panelY, colW, "EQUIPEMENT",
                     ImVec4(0.5f, 0.75f, 1.f, 1.f));

    {
        float ey   = panelY + pad * 2.5f;
        float exPad = col2X + pad;
        ImU32 eqColor  = ImGui::GetColorU32(ImVec4(1.f,   1.f,   1.f,   1.f));
        ImU32 emColor  = ImGui::GetColorU32(ImVec4(0.4f,  0.4f,  0.4f,  1.f));
        ImU32 lblColor = ImGui::GetColorU32(ImVec4(0.65f, 0.65f, 0.65f, 1.f));
        float rowH = 22.f;

        // Largeur label calculée sur le texte le plus long
        float valX   = exPad + ImGui::CalcTextSize("Main G.  ").x;
        float maxValW = col2X + colW - pad - valX;

        auto slotVal = [&](const Item* item) -> std::string
        {
            if (!item) return "vide";
            std::string n = item->name;
            while (n.size() > 2 && ImGui::CalcTextSize(n.c_str()).x > maxValW)
                n.pop_back();
            if (n.size() < item->name.size()) n += ".";
            return n;
        };

        auto drawSlot = [&](const char* label, const Item* item)
        {
            dl->AddText(ImVec2(exPad, ey), lblColor, label);
            std::string v = slotVal(item);
            dl->AddText(ImVec2(valX, ey), item ? eqColor : emColor, v.c_str());
            ey += rowH;
        };

        auto& eq = player.equipment;
        drawSlot("Tete",    eq.head);
        drawSlot("Torse",   eq.chest);

        if (eq.handR && eq.handR->slotType == EquipSlot::TWO_HANDS)
        {
            dl->AddText(ImVec2(exPad, ey), lblColor, "2 Mains");
            std::string v = slotVal(eq.handR);
            dl->AddText(ImVec2(valX, ey), eqColor, v.c_str());
            ey += rowH;
        }
        else
        {
            drawSlot("Main D.", eq.handR);
            drawSlot("Main G.", eq.handL);
        }

        drawSlot("Jambes",  eq.legs);
        drawSlot("Pieds",   eq.feet);
        drawSlot("Cou",     eq.neck);

        for (int i = 0; i < 3; i++)
        {
            char ringLabel[10];
            snprintf(ringLabel, sizeof(ringLabel), "Bague %d", i + 1);
            drawSlot(ringLabel, eq.ring[i]);
        }

        // Compteur consommables
        ey += 6.f;
        char cBuf[32];
        snprintf(cBuf, sizeof(cBuf), "Consom. : %d/%d",
                 player.consumableCount(), Player::MAX_CONSUMABLES);
        dl->AddText(ImVec2(exPad, ey),
            ImGui::GetColorU32(
                player.consumableCount() >= Player::MAX_CONSUMABLES
                    ? ImVec4(0.8f, 0.4f, 0.2f, 1.f)
                    : ImVec4(0.6f, 0.85f, 0.5f, 1.f)),
            cBuf);
        ey += 24.f;

        // Séparateur stats
        ImVec2 wPosE = ImGui::GetWindowPos();
        dl->AddLine(ImVec2(wPosE.x + col2X + pad, wPosE.y + ey),
                    ImVec2(wPosE.x + col2X + colW - pad, wPosE.y + ey),
                    ImGui::GetColorU32(ImVec4(0.3f, 0.3f, 0.3f, 0.5f)));
        ey += 8.f;

        // Stats du joueur
        auto statLine = [&](const char* lbl, float val)
        {
            char sb[32];
            snprintf(sb, sizeof(sb), "%-10s %.0f", lbl, val);
            dl->AddText(ImVec2(exPad, ey),
                ImGui::GetColorU32(ImVec4(0.7f, 0.7f, 0.7f, 1.f)), sb);
            ey += 18.f;
        };
        statLine("ATK :",  player.baseDommage);
        statLine("DEF :",  player.baseDefense);
        statLine("OR  :",  (float)player.gold);
        char xpBuf[32];
        snprintf(xpBuf, sizeof(xpBuf), "XP  :  %d/100", player.xp);
        dl->AddText(ImVec2(exPad, ey),
            ImGui::GetColorU32(ImVec4(0.7f, 0.7f, 0.7f, 1.f)), xpBuf);
    }

    // ── Repos ─────────────────────────────────────────────────
    drawPanel(dl, col3X, panelY, colW, panelH,
              ImVec4(0.2f, 0.7f, 0.3f, 0.8f));
    drawSectionTitle(dl, col3X, panelY, colW, "REPOS",
                     ImVec4(0.3f, 0.9f, 0.4f, 1.f));

    float reposY = panelY + pad * 2.5f;

    // ── Choix de level up (prioritaire) ───────────────────────
    if (player.pendingLevelUps > 0)
    {
        // Badge level up
        char lvlBuf[48];
        snprintf(lvlBuf, sizeof(lvlBuf), "NIVEAU %d !", player.level);
        ImVec2 lSz = ImGui::CalcTextSize(lvlBuf);
        ImVec2 wPos = ImGui::GetWindowPos();
        dl->AddText(ImVec2(wPos.x + col3X + (colW - lSz.x) * 0.5f,
                           wPos.y + reposY),
                    ImGui::GetColorU32(ImVec4(1.f, 0.85f, 0.2f, 1.f)), lvlBuf);
        reposY += lSz.y + 6.f;

        char pendBuf[32];
        snprintf(pendBuf, sizeof(pendBuf), "(%d choix restant%s)",
                 player.pendingLevelUps,
                 player.pendingLevelUps > 1 ? "s" : "");
        ImVec2 pSz = ImGui::CalcTextSize(pendBuf);
        dl->AddText(ImVec2(wPos.x + col3X + (colW - pSz.x) * 0.5f,
                           wPos.y + reposY),
                    ImGui::GetColorU32(ImVec4(0.6f, 0.6f, 0.6f, 1.f)), pendBuf);
        reposY += pSz.y + 12.f;

        // Bouton HP+15
        ImGui::SetCursorPos(ImVec2(col3X + pad, reposY));
        if (actionButton("HP Max +15##lvlhp", ImVec2(btnW, btnH)))
        {
            playButtonSound();
            player.hpMax += 15.f;
            player.hp    += 15.f;
            if (player.hp > player.hpMax) player.hp = player.hpMax;
            player.pendingLevelUps--;
        }
        reposY += btnH + 8.f;

        // Bouton ATK+2
        ImGui::SetCursorPos(ImVec2(col3X + pad, reposY));
        if (actionButton("ATK +2##lvlatk", ImVec2(btnW, btnH)))
        {
            playButtonSound();
            player.baseDommage += 2.f;
            player.pendingLevelUps--;
        }
        reposY += btnH + 8.f;

        // Bouton DEF+1
        ImGui::SetCursorPos(ImVec2(col3X + pad, reposY));
        if (actionButton("DEF +1##lvldef", ImVec2(btnW, btnH)))
        {
            playButtonSound();
            player.baseDefense += 1.f;
            player.pendingLevelUps--;
        }
        reposY += btnH + 14.f;

        // Séparateur avant le soin
        ImVec2 wPos2 = ImGui::GetWindowPos();
        dl->AddLine(ImVec2(wPos2.x + col3X + pad, wPos2.y + reposY),
                    ImVec2(wPos2.x + col3X + colW - pad, wPos2.y + reposY),
                    ImGui::GetColorU32(ImVec4(0.3f, 0.3f, 0.3f, 0.5f)));
        reposY += 10.f;
    }

    // ── Soin standard ────────────────────────────────────────
    float healAmount = player.hpMax * 0.30f;
    char  healBuf[64];
    snprintf(healBuf, sizeof(healBuf), "Soigner (+ %.0f HP)", healAmount);

    ImGui::SetCursorPos(ImVec2(col3X + pad, reposY));
    drawBar(dl, ImGui::GetCursorScreenPos(), btnW, 16.f,
            player.hp, player.hpMax,
            ImVec4(0.2f, 0.8f, 0.3f, 1.f), "HP");
    ImGui::Dummy(ImVec2(btnW, 22.f));

    reposY += 28.f;
    ImGui::SetCursorPos(ImVec2(col3X + pad, reposY));
    if (actionButton(healBuf, ImVec2(btnW, btnH),
                     player.hp >= player.hpMax || game.healUsed))
    {
        playButtonSound();
        player.hp = std::min(player.hp + healAmount, player.hpMax);
        game.healUsed = true;
    }
    if (game.healUsed)
    {
        reposY += btnH + 4.f;
        ImVec2 wPosR = ImGui::GetWindowPos();
        const char* usedMsg = "Soin utilise";
        ImVec2 uSz = ImGui::CalcTextSize(usedMsg);
        dl->AddText(ImVec2(wPosR.x + col3X + (colW - uSz.x) * 0.5f,
                           wPosR.y + reposY),
                    ImGui::GetColorU32(ImVec4(0.5f, 0.5f, 0.5f, 1.f)), usedMsg);
    }

    // ── Consommables utilisables au repos ─────────────────────
    {
        reposY += game.healUsed ? btnH + 18.f : btnH + 14.f;

        bool hasConsumable = false;
        for (int i = 0; i < (int)player.inventory.slots.size(); i++)
        {
            InventorySlot& slot = player.inventory.slots[i];
            if (!slot.item || slot.item->type != ItemType::CONSUMABLE) continue;

            hasConsumable = true;

            // Nom + quantité
            char cLabel[64];
            snprintf(cLabel, sizeof(cLabel), "%s (%d)##repos%d",
                     slot.item->name.c_str(), slot.quantity, i);

            ImGui::SetCursorPos(ImVec2(col3X + pad + 28.f, reposY));
            if (actionButton(cLabel, ImVec2(btnW, 24.f)))
            {
                playButtonSound();
                player.inventory.use(i, &player, &game.combatLog);
                break;
            }
            reposY += 30.f;

            if (reposY > panelY + panelH - pad * 2.f) break;
        }

        if (!hasConsumable)
        {
            ImVec2 wPosC = ImGui::GetWindowPos();
            const char* noMsg = "Aucun consommable";
            ImVec2 nSz = ImGui::CalcTextSize(noMsg);
            dl->AddText(ImVec2(wPosC.x + col3X + (colW - nSz.x) * 0.5f,
                               wPosC.y + reposY),
                        ImGui::GetColorU32(ImVec4(0.4f, 0.4f, 0.4f, 1.f)), noMsg);
        }
    }

    // ── Marchand ──────────────────────────────────────────────
    drawPanel(dl, col4X, panelY, colW, panelH,
              ImVec4(0.5f, 0.3f, 0.7f, 0.8f));
    drawSectionTitle(dl, col4X, panelY, colW, "MARCHAND",
                     ImVec4(0.75f, 0.5f, 0.95f, 1.f));

    char goldBuf[32];
    snprintf(goldBuf, sizeof(goldBuf), "Or : %d", player.gold);
    dl->AddText(ImVec2(col4X + pad, panelY + pad * 2.5f),
        ImGui::GetColorU32(ImVec4(0.95f, 0.80f, 0.2f, 1.f)), goldBuf);

    float shopY = panelY + pad * 4.f;
    for (Item* item : game.shopPool)
    {
        // Nom tronqué + prix à droite
        {
            std::string n = item->name;
            float maxW = colW - pad * 2.f - ImGui::CalcTextSize("999 Or").x - 8.f;
            while (n.size() > 2 && ImGui::CalcTextSize(n.c_str()).x > maxW) n.pop_back();
            if (n.size() < item->name.size()) n += ".";
            ImVec2 wPS = ImGui::GetWindowPos();
            dl->AddText(ImVec2(wPS.x + col4X + pad, wPS.y + shopY),
                ImGui::GetColorU32(ImVec4(1.f, 1.f, 1.f, 1.f)), n.c_str());
            char priceBuf[16];
            snprintf(priceBuf, sizeof(priceBuf), "%d Or", item->value);
            ImVec2 prSz = ImGui::CalcTextSize(priceBuf);
            bool afford = player.gold >= item->value;
            dl->AddText(ImVec2(wPS.x + col4X + colW - pad - prSz.x, wPS.y + shopY),
                ImGui::GetColorU32(afford
                    ? ImVec4(0.95f, 0.80f, 0.2f, 1.f)
                    : ImVec4(0.45f, 0.35f, 0.1f,  1.f)), priceBuf);
            shopY += 18.f;
            const char* tStr = item->type == ItemType::EQUIPPABLE ? "Equip." : "Consom.";
            dl->AddText(ImVec2(wPS.x + col4X + pad, wPS.y + shopY),
                ImGui::GetColorU32(ImVec4(0.42f, 0.42f, 0.42f, 1.f)), tStr);
            shopY += 16.f;
        }

        ImGui::SetCursorPos(ImVec2(col4X + pad, shopY));
        char buyLabel[64];
        snprintf(buyLabel, sizeof(buyLabel), "Acheter##%d", item->id);
        bool cantAfford = player.gold < item->value ||
                         (item->type == ItemType::CONSUMABLE &&
                          player.consumableCount() >= Player::MAX_CONSUMABLES);
        const char* shopTip = item->description.empty() ? nullptr : item->description.c_str();
        if (actionButton(buyLabel, ImVec2(btnW, btnH), cantAfford, shopTip))
        {
            playButtonSound();
            player.gold -= item->value;
            if (item->type == ItemType::EQUIPPABLE)
            {
                if (item->slotType == EquipSlot::RING &&
                    player.equipment.firstFreeRingSlot() < 0)
                {
                    game.pendingRingChoice = true;
                    game.pendingRingItem   = item;
                }
                else
                {
                    player.equipItem(item, &game.combatLog);
                    player.inventory.add(item, 1, &game.combatLog);
                    game.shopPool.erase(
                        std::remove(game.shopPool.begin(),
                                    game.shopPool.end(), item),
                        game.shopPool.end());
                }
            }
            else
            {
                player.inventory.add(item, 1, &game.combatLog);
                game.shopPool.erase(
                    std::remove(game.shopPool.begin(),
                                game.shopPool.end(), item),
                    game.shopPool.end());
            }
            break;
        }
        shopY += btnH + 12.f;
    }
    if (game.shopPool.empty())
    {
        ImGui::SetCursorPos(ImVec2(col4X + pad, panelY + panelH * 0.5f));
        ImGui::TextDisabled("Stock epuise");
    }

    // ── Chemin ────────────────────────────────────────────────
    drawPanel(dl, col5X, panelY, colW, panelH,
              ImVec4(0.6f, 0.2f, 0.2f, 0.8f));
    drawSectionTitle(dl, col5X, panelY, colW, "CHEMIN",
                     ImVec4(0.9f, 0.3f, 0.3f, 1.f));

    float pathY = panelY + pad * 2.5f;

    // Si pas encore de choix générés, on propose les deux options
    if (game.pathChoices.empty())
    {
        ImGui::SetCursorPos(ImVec2(col5X + pad, pathY));
        if (actionButton("Voie normale##easy", ImVec2(btnW, btnH)))
        {
            playButtonSound();
            if (fadeState == FadeState::NONE) game.buildPath(false);
        }
        pathY += btnH + 10.f;

        if (!game.isLastCombat())
        {
            ImGui::SetCursorPos(ImVec2(col5X + pad, pathY));
            if (actionButton("Voie perilleuse##hard", ImVec2(btnW, btnH)))
            {
                playButtonSound();
                if (fadeState == FadeState::NONE) game.buildPath(true);
            }
            pathY += btnH + 10.f;

            dl->AddText(ImVec2(col5X + pad, pathY),
                ImGui::GetColorU32(ImVec4(0.9f, 0.5f, 0.2f, 1.f)),
                "Monstre plus fort,");
            pathY += 18.f;
            dl->AddText(ImVec2(col5X + pad, pathY),
                ImGui::GetColorU32(ImVec4(0.9f, 0.5f, 0.2f, 1.f)),
                "meilleures recompenses.");
        }
    }
    else
    {
        // Choix generé — afficher les options
        for (int i = 0; i < (int)game.pathChoices.size(); i++)
        {
            Monster& m      = game.pathChoices[i];
            bool     isHard = (i == 1);

            // Nom + catégorie
            dl->AddText(ImVec2(col5X + pad, pathY),
                ImGui::GetColorU32(ImVec4(1.f, 1.f, 1.f, 1.f)),
                m.name.c_str());
            pathY += 20.f;

            const char* cat =
                (m.category == MonsterCategory::BOSS)      ? "[BOSS]"      :
                (m.category == MonsterCategory::MINI_BOSS) ? "[Mini-Boss]" :
                isHard                                      ? "[Difficile]" :
                                                              "[Normal]";
            dl->AddText(ImVec2(col5X + pad, pathY),
                ImGui::GetColorU32(isHard
                    ? ImVec4(0.9f, 0.4f, 0.2f, 1.f)
                    : ImVec4(0.6f, 0.6f, 0.6f, 1.f)), cat);
            pathY += 20.f;

            // ── Aperçu stats du monstre ───────────────────────
            ImU32 statCol = ImGui::GetColorU32(ImVec4(0.7f, 0.7f, 0.7f, 1.f));
            char statBuf[48];

            snprintf(statBuf, sizeof(statBuf), "HP  : %.0f", m.hpMax);
            dl->AddText(ImVec2(col5X + pad, pathY), statCol, statBuf);
            pathY += 18.f;

            snprintf(statBuf, sizeof(statBuf), "ATK : %.0f", m.baseDommage);
            dl->AddText(ImVec2(col5X + pad, pathY), statCol, statBuf);
            pathY += 18.f;

            snprintf(statBuf, sizeof(statBuf), "DEF : %.0f", m.baseDefense);
            dl->AddText(ImVec2(col5X + pad, pathY), statCol, statBuf);
            pathY += 18.f;

            snprintf(statBuf, sizeof(statBuf), "Mercy : 0/%d", m.mercyGoal);
            dl->AddText(ImVec2(col5X + pad, pathY), statCol, statBuf);
            pathY += 22.f;

            // Séparateur entre les deux choix
            if (i == 0 && game.pathChoices.size() > 1)
            {
                dl->AddLine(ImVec2(col5X + pad, pathY + 2.f),
                            ImVec2(col5X + colW - pad, pathY + 2.f),
                            ImGui::GetColorU32(ImVec4(0.3f, 0.3f, 0.3f, 0.6f)));
                pathY += 10.f;
            }

            ImGui::SetCursorPos(ImVec2(col5X + pad, pathY));
            char chooseLabel[64];
            snprintf(chooseLabel, sizeof(chooseLabel), "Affronter##%d", i);
            if (actionButton(chooseLabel, ImVec2(btnW, btnH)))
            {
                playButtonSound();
                game.startCombat(i); // startCombat gère screen = COMBAT
            }
            pathY += btnH + 14.f;
        }
    }

    ImGui::End();

    // ── Popup choix de bague ─────────────────────────────────
    if (game.pendingRingChoice && game.pendingRingItem &&
        game.currentPlayer.has_value())
        renderRingChoice(game);
}

// Helper : nom d'affichage d'un slot
static const char* slotName(EquipSlot slot)
{
    switch (slot) {
        case EquipSlot::HEAD:      return "Tete";
        case EquipSlot::CHEST:     return "Torse";
        case EquipSlot::MAIN_HAND: return "Main";
        case EquipSlot::TWO_HANDS: return "2 Mains";
        case EquipSlot::LEGS:      return "Jambes";
        case EquipSlot::FEET:      return "Pieds";
        case EquipSlot::NECK:      return "Cou";
        case EquipSlot::RING:      return "Bague";
        default:                   return "";
    }
}

// ============================================================
//  POPUP — CHOIX DE SLOT BAGUE
// ============================================================

void Interface::renderRingChoice(Game& game)
{
    Player& player = game.currentPlayer.value();
    Item*   item   = game.pendingRingItem;
    if (!item) { game.pendingRingChoice = false; return; }

    float scrW = (float)window.getSize().x;
    float scrH = (float)window.getSize().y;

    ImGui::SetNextWindowPos(ImVec2(0, 0));
    ImGui::SetNextWindowSize(ImVec2(scrW, scrH));
    ImGui::SetNextWindowBgAlpha(1.0f);
    ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.f, 0.f, 0.f, 0.80f));

    ImGuiWindowFlags flags = ImGuiWindowFlags_NoDecoration
                           | ImGuiWindowFlags_NoMove
                           | ImGuiWindowFlags_NoSavedSettings
                           | ImGuiWindowFlags_NoNav;

    if (!ImGui::Begin("##ring_choice", nullptr, flags))
    {
        ImGui::PopStyleColor();
        ImGui::End(); return;
    }

    ImDrawList* dl   = ImGui::GetWindowDrawList();
    ImVec2      wPos = ImGui::GetWindowPos();
    float W = scrW, H = scrH;

    float panelW = W * 0.38f;
    float panelH = H * 0.42f;
    float absPX  = wPos.x + (W - panelW) * 0.5f;
    float absPY  = wPos.y + (H - panelH) * 0.5f;
    float panelX = (W - panelW) * 0.5f;
    float panelY = (H - panelH) * 0.5f;

    dl->AddRectFilled(ImVec2(absPX, absPY),
                      ImVec2(absPX + panelW, absPY + panelH),
                      ImGui::GetColorU32(ImVec4(0.08f, 0.08f, 0.08f, 0.97f)), 10.f);
    dl->AddRect(ImVec2(absPX, absPY),
                ImVec2(absPX + panelW, absPY + panelH),
                ImGui::GetColorU32(ImVec4(0.7f, 0.5f, 0.9f, 1.f)), 10.f, 0, 2.f);

    const char* title = "Remplacer quelle bague ?";
    ImVec2 tSz = ImGui::CalcTextSize(title);
    dl->AddText(ImVec2(absPX + (panelW - tSz.x) * 0.5f, absPY + 16.f),
                ImGui::GetColorU32(ImVec4(0.85f, 0.6f, 1.f, 1.f)), title);

    ImVec2 nSz = ImGui::CalcTextSize(item->name.c_str());
    dl->AddText(ImVec2(absPX + (panelW - nSz.x) * 0.5f, absPY + 44.f),
                ImGui::GetColorU32(ImVec4(1.f, 0.85f, 0.35f, 1.f)),
                item->name.c_str());

    float btnW   = panelW * 0.70f;
    float btnH   = H / 18.f;
    float startY = panelY + panelH * 0.30f;

    for (int i = 0; i < 3; i++)
    {
        Item* ring = player.equipment.ring[i];
        char label[64];
        snprintf(label, sizeof(label), "Slot %d : %s##ring%d",
                 i + 1, ring ? ring->name.c_str() : "Vide", i);

        ImGui::SetCursorPos(ImVec2(panelX + (panelW - btnW) * 0.5f,
                                   startY + i * (btnH + 10.f)));
        if (actionButton(label, ImVec2(btnW, btnH)))
        {
            playButtonSound();
            player.equipItem(item, &game.combatLog, i);
            player.inventory.add(item, 1, &game.combatLog);
            auto& lp = game.lootPool;
            lp.erase(std::remove(lp.begin(), lp.end(), item), lp.end());
            auto& sp = game.shopPool;
            sp.erase(std::remove(sp.begin(), sp.end(), item), sp.end());
            game.pendingRingChoice = false;
            game.pendingRingItem   = nullptr;
        }
    }

    float cancelY = startY + 3.f * (btnH + 10.f) + 8.f;
    ImGui::SetCursorPos(ImVec2(panelX + (panelW - btnW) * 0.5f, cancelY));
    if (actionButton("Annuler##ringcancel", ImVec2(btnW, btnH)))
    {
        playButtonSound();
        game.pendingRingChoice = false;
        game.pendingRingItem   = nullptr;
    }

    ImGui::PopStyleColor();
    ImGui::End();
}

// ============================================================
//  POPUP — PAUSE
// ============================================================

void Interface::renderPause(Game& game)
{
    float scrW = (float)window.getSize().x;
    float scrH = (float)window.getSize().y;

    ImGui::SetNextWindowPos(ImVec2(0, 0));
    ImGui::SetNextWindowSize(ImVec2(scrW, scrH));
    ImGui::SetNextWindowBgAlpha(1.0f);
    ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.f, 0.f, 0.f, 0.78f));

    ImGuiWindowFlags flags = ImGuiWindowFlags_NoDecoration
                           | ImGuiWindowFlags_NoMove
                           | ImGuiWindowFlags_NoSavedSettings
                           | ImGuiWindowFlags_NoNav;

    if (!ImGui::Begin("##pause_popup", nullptr, flags))
    {
        ImGui::PopStyleColor();
        ImGui::End(); return;
    }

    ImDrawList* dl   = ImGui::GetWindowDrawList();
    ImVec2      wPos = ImGui::GetWindowPos();
    float W = scrW, H = scrH;

    float panelW = W * 0.32f;
    float panelH = H * 0.36f;
    float absPX  = wPos.x + (W - panelW) * 0.5f;
    float absPY  = wPos.y + (H - panelH) * 0.5f;
    float panelX = (W - panelW) * 0.5f;
    float panelY = (H - panelH) * 0.5f;
    float btnW   = panelW * 0.65f;
    float btnH   = H / 16.f;

    dl->AddRectFilled(ImVec2(absPX, absPY),
                      ImVec2(absPX + panelW, absPY + panelH),
                      ImGui::GetColorU32(ImVec4(0.08f, 0.08f, 0.08f, 0.97f)), 10.f);
    dl->AddRect(ImVec2(absPX, absPY),
                ImVec2(absPX + panelW, absPY + panelH),
                ImGui::GetColorU32(ImVec4(0.55f, 0.45f, 0.15f, 0.9f)), 10.f, 0, 2.f);

    const char* title = "PAUSE";
    ImVec2 tSz = ImGui::CalcTextSize(title);
    dl->AddText(ImVec2(absPX + (panelW - tSz.x) * 0.5f, absPY + 18.f),
                ImGui::GetColorU32(ImVec4(0.95f, 0.80f, 0.35f, 1.f)), title);

    float bx = panelX + (panelW - btnW) * 0.5f;

    ImGui::SetCursorPos(ImVec2(bx, panelY + panelH * 0.30f));
    if (actionButton("Reprendre##pause", ImVec2(btnW, btnH)))
    {
        playButtonSound();
        paused = false;
    }

    ImGui::SetCursorPos(ImVec2(bx, panelY + panelH * 0.57f));
    if (actionButton("Menu principal##pause", ImVec2(btnW, btnH)))
    {
        playButtonSound();
        paused = false;
        game.saveSave(); // sauvegarde explicite avant de quitter
        startFade(GameScreen::MENU);
    }

    ImGui::PopStyleColor();
    ImGui::End();
}

// ============================================================

void Interface::renderEndRun(Game& game)
{
    if (!beginFullscreen("##endrun")) { ImGui::End(); return; }

    drawBackground();

    float winW = ImGui::GetWindowWidth();
    float winH = ImGui::GetWindowHeight();
    ImDrawList* dl = ImGui::GetWindowDrawList();

    float panelW = winW * 0.50f;
    float panelH = winH * 0.55f;
    float panelX = (winW - panelW) * 0.5f;
    float panelY = (winH - panelH) * 0.5f;
    float btnW   = panelW * 0.45f;
    float btnH   = winH / 16.f;

    ImVec4 borderColor;
    ImVec4 titleColor;
    const char* endTitle = "";

    switch (game.runEnding)
    {
        case RunEnding::CONQUETE:
            borderColor = ImVec4(0.8f, 0.2f, 0.2f, 1.f);
            titleColor  = ImVec4(1.f, 0.3f, 0.3f, 1.f);
            endTitle    = "CONQUETE";
            break;
        case RunEnding::REDEMPTION:
            borderColor = ImVec4(0.2f, 0.7f, 0.9f, 1.f);
            titleColor  = ImVec4(0.4f, 0.85f, 1.f, 1.f);
            endTitle    = "REDEMPTION";
            break;
        case RunEnding::MORT:
            borderColor = ImVec4(0.3f, 0.3f, 0.3f, 1.f);
            titleColor  = ImVec4(0.6f, 0.6f, 0.6f, 1.f);
            endTitle    = "DEFAITE";
            break;
        default:
            borderColor = ImVec4(0.7f, 0.6f, 0.2f, 1.f);
            titleColor  = ImVec4(1.f, 0.85f, 0.35f, 1.f);
            endTitle    = "EQUILIBRE";
            break;
    }

    drawPanel(dl, panelX, panelY, panelW, panelH, borderColor);

    ImVec2 tSize = ImGui::CalcTextSize(endTitle);
    dl->AddText(
        ImVec2(panelX + (panelW - tSize.x) * 0.5f, panelY + panelH * 0.12f),
        ImGui::GetColorU32(titleColor), endTitle);

    {
        float col1X = panelX + 30.f;
        float col2X = panelX + panelW * 0.52f;
        float sy1   = panelY + panelH * 0.25f;
        float sy2   = panelY + panelH * 0.25f;
        float rowH  = 26.f;

        auto line = [&](const char* label, int val, float& sy, float sx)
        {
            char buf[64];
            snprintf(buf, sizeof(buf), "%-22s %d", label, val);
            dl->AddText(ImVec2(sx, sy),
                ImGui::GetColorU32(ImVec4(0.9f, 0.9f, 0.9f, 1.f)), buf);
            sy += rowH;
        };

        // Séparateur central
        dl->AddLine(ImVec2(panelX + panelW * 0.50f, panelY + panelH * 0.22f),
                    ImVec2(panelX + panelW * 0.50f, panelY + panelH * 0.88f),
                    ImGui::GetColorU32(ImVec4(0.3f, 0.3f, 0.3f, 0.5f)));

        // Colonne gauche — résultats du run
        dl->AddText(ImVec2(col1X, sy1),
            ImGui::GetColorU32(ImVec4(0.7f, 0.7f, 0.7f, 1.f)), "-- Resultats --");
        sy1 += rowH;
        line("Monstres tues",     game.lastRunStats.nbKilled, sy1, col1X);
        line("Monstres epargnes", game.lastRunStats.nbSpared, sy1, col1X);
        line("Niveau atteint",    game.lastRunStats.level,    sy1, col1X);
        line("Or accumule",       game.lastRunStats.gold,     sy1, col1X);

        // Colonne droite — stats de combat
        dl->AddText(ImVec2(col2X, sy2),
            ImGui::GetColorU32(ImVec4(0.7f, 0.7f, 0.7f, 1.f)), "-- Combat --");
        sy2 += rowH;
        line("Degats infliges",   game.combatStats.dmgDealt,     sy2, col2X);
        line("Degats recus",      game.combatStats.dmgReceived,  sy2, col2X);
        line("Mercy inflige",     game.combatStats.mercyDealt,   sy2, col2X);
        line("Tours joues",       game.combatStats.turnsPlayed,  sy2, col2X);
    }

    float bx = panelX + (panelW - btnW) * 0.5f;

    ImGui::SetCursorPos(ImVec2(bx, panelY + panelH * 0.72f));
    if (actionButton("Rejouer", ImVec2(btnW, btnH)))
    {
        playButtonSound();
        selectedClass = -1;
        memset(seedInput, 0, sizeof(seedInput));
        memset(nameInput, 0, sizeof(nameInput));
        startFade(GameScreen::CLASS_SELECT);
    }

    ImGui::SetCursorPos(ImVec2(bx, panelY + panelH * 0.85f));
    if (actionButton("Menu principal", ImVec2(btnW, btnH)))
    {
        playButtonSound();
        startFade(GameScreen::MENU);
    }

    ImGui::End();
}