#include "action.h"
#include "entity.h"

#define LOG(msg) if(log) log->push_back(msg)

void Action::apply(Entity* target, std::vector<std::string>* log)
{
    if (!target) return;

    switch (type)
    {
        case ActionType::DOMMAGE:
        {
            float dmg = value - target->baseDefense;
            if (dmg < 0) dmg = 0;
            target->hp -= dmg;
            if (target->hp < 0) target->hp = 0;
            LOG(target->name + " prend " + std::to_string((int)dmg) + " degats");
            break;
        }
        case ActionType::HEAL:
            target->hp += value;
            if (target->hp > target->hpMax) target->hp = target->hpMax;
            LOG(target->name + " recup " + std::to_string((int)value) + " HP");
            break;

        case ActionType::BUFF_ATK:
            target->baseDommage += value;
            LOG(target->name + " atk +" + std::to_string((int)value));
            break;

        case ActionType::BUFF_DEF:
            target->baseDefense += value;
            LOG(target->name + " def +" + std::to_string((int)value));
            break;

        case ActionType::DEBUFF_ATK:
            target->baseDommage -= value;
            if (target->baseDommage < 0) target->baseDommage = 0;
            LOG(target->name + " atk -" + std::to_string((int)value));
            break;

        case ActionType::DEBUFF_DEF:
            target->baseDefense -= value;
            if (target->baseDefense < 0) target->baseDefense = 0;
            LOG(target->name + " def -" + std::to_string((int)value));
            break;

        case ActionType::MERCY_DOMMAGE:
        {
            float gain = value - target->baseDefense * 0.3f;
            if (gain < 1) gain = 1;
            target->mercy += (int)gain;
            if (target->mercy > target->mercyGoal) target->mercy = target->mercyGoal;
            LOG(target->name + " mercy +" + std::to_string((int)gain)
                + " (" + std::to_string(target->mercy) + "/" + std::to_string(target->mercyGoal) + ")");
            break;
        }
        case ActionType::MERCY_HEAL:
        {
            float loss = value - target->baseDefense * 0.3f;
            if (loss < 1) loss = 1;
            target->mercy -= (int)loss;
            if (target->mercy < 0) target->mercy = 0;
            LOG(target->name + " mercy -" + std::to_string((int)loss)
                + " (" + std::to_string(target->mercy) + "/" + std::to_string(target->mercyGoal) + ")");
            break;
        }

        case ActionType::DOMMAGE_TIME:
            target->activeEffects.push_back({ActionType::DOMMAGE_TIME, value, 3});
            LOG(target->name + " empoisonne (3 tours)");
            break;

        case ActionType::HEAL_TIME:
            target->activeEffects.push_back({ActionType::HEAL_TIME, value, 3});
            LOG(target->name + " regeneration (3 tours)");
            break;

        case ActionType::BUFF_ATK_TIME:
            target->baseDommage += value;
            target->activeEffects.push_back({ActionType::BUFF_ATK_TIME, value, 3});
            LOG(target->name + " atk +" + std::to_string((int)value) + " (3 tours)");
            break;

        case ActionType::BUFF_DEF_TIME:
            target->baseDefense += value;
            target->activeEffects.push_back({ActionType::BUFF_DEF_TIME, value, 3});
            LOG(target->name + " def +" + std::to_string((int)value) + " (3 tours)");
            break;

        case ActionType::DEBUFF_ATK_TIME:
            target->baseDommage -= value;
            if (target->baseDommage < 0) target->baseDommage = 0;
            target->activeEffects.push_back({ActionType::DEBUFF_ATK_TIME, value, 3});
            LOG(target->name + " atk -" + std::to_string((int)value) + " (3 tours)");
            break;

        case ActionType::DEBUFF_DEF_TIME:
            target->baseDefense -= value;
            if (target->baseDefense < 0) target->baseDefense = 0;
            target->activeEffects.push_back({ActionType::DEBUFF_DEF_TIME, value, 3});
            LOG(target->name + " def -" + std::to_string((int)value) + " (3 tours)");
            break;

        case ActionType::MERCY_DOMMAGE_TIME:
            target->activeEffects.push_back({ActionType::MERCY_DOMMAGE_TIME, value, 3});
            LOG(target->name + " mercy+ (3 tours)");
            break;

        case ActionType::MERCY_HEAL_TIME:
            target->activeEffects.push_back({ActionType::MERCY_HEAL_TIME, value, 3});
            LOG(target->name + " mercy- (3 tours)");
            break;

        case ActionType::CONDITIONAL:
        {
            float stat = 0.f;
            switch (statSelect) {
                case StatSelect::HP:           stat = target->hp;            break;
                case StatSelect::MERCY:        stat = (float)target->mercy;  break;
                case StatSelect::BASE_DOMMAGE: stat = target->baseDommage;   break;
                case StatSelect::BASE_DEFENSE: stat = target->baseDefense;   break;
                case StatSelect::NONE:         stat = 0.f;                   break;
            }
            bool triggered = triggerIfAbove ? stat >= threshold : stat <= threshold;
            if (triggered) {
                LOG(name + " declenche !");
                for (Action* sub : subActions) sub->apply(target, log);
            }
            return; // pas de cascade subActions en dessous
        }
    }

    for (Action* sub : subActions) sub->apply(target, log);
}