#include "player.h"

#define LOG(msg) if(log) log->push_back(msg)

void Player::gainXP(int amount, std::vector<std::string>* log)
{
    xp += amount;

    while (xp >= 100)
    {
        xp -= 100;
        level++;
        pendingLevelUps++;
        LOG(name + " passe niveau " + std::to_string(level) + " !");
        LOG("  Choisissez un bonus dans l'ecran de repos.");
    }
}

void Player::resetRunStats()
{
    nbKilled = 0;
    nbSpared = 0;
    victory  = 0;
}

int Player::consumableCount() const
{
    int n = 0;
    for (const auto& slot : inventory.slots)
        if (slot.item && slot.item->type == ItemType::CONSUMABLE)
            n += slot.quantity;
    return n;
}

bool Player::equipItem(Item* item, std::vector<std::string>* log, int ringSlot)
{
    if (!item || item->type != ItemType::EQUIPPABLE) return false;

    switch (item->slotType)
    {
        case EquipSlot::HEAD:
            if (equipment.head) { unequipSlot(EquipSlot::HEAD, 0, log); }
            equipment.head = item;
            break;

        case EquipSlot::CHEST:
            if (equipment.chest) { unequipSlot(EquipSlot::CHEST, 0, log); }
            equipment.chest = item;
            break;

        case EquipSlot::LEGS:
            if (equipment.legs) { unequipSlot(EquipSlot::LEGS, 0, log); }
            equipment.legs = item;
            break;

        case EquipSlot::FEET:
            if (equipment.feet) { unequipSlot(EquipSlot::FEET, 0, log); }
            equipment.feet = item;
            break;

        case EquipSlot::NECK:
            if (equipment.neck) { unequipSlot(EquipSlot::NECK, 0, log); }
            equipment.neck = item;
            break;

        case EquipSlot::MAIN_HAND:
            // Main droite en priorité, gauche si droite occupée
            if (!equipment.handR)
                equipment.handR = item;
            else if (!equipment.handL)
                equipment.handL = item;
            else
            {
                // Les deux mains prises : remplace la droite
                unequipSlot(EquipSlot::MAIN_HAND, 0, log);
                equipment.handR = item;
            }
            break;

        case EquipSlot::TWO_HANDS:
            // Libère les deux mains
            if (equipment.handR) unequipSlot(EquipSlot::MAIN_HAND, 0, log);
            if (equipment.handL) unequipSlot(EquipSlot::MAIN_HAND, 1, log);
            equipment.handR = item;
            equipment.handL = nullptr; // marqué occupé par 2 mains
            break;

        case EquipSlot::RING:
        {
            int slot = (ringSlot >= 0 && ringSlot < 3)
                        ? ringSlot
                        : equipment.firstFreeRingSlot();
            if (slot < 0) return false; // tous les slots pleins → caller doit demander le choix
            if (equipment.ring[slot]) unequipSlot(EquipSlot::RING, slot, log);
            equipment.ring[slot] = item;
            break;
        }

        default: return false;
    }

    item->applyEquipEffects(this, log);
    rebuildActions();
    return true;
}

void Player::unequipSlot(EquipSlot slot, int ringIndex,
                          std::vector<std::string>* log)
{
    Item** target = nullptr;

    switch (slot)
    {
        case EquipSlot::HEAD:      target = &equipment.head;  break;
        case EquipSlot::CHEST:     target = &equipment.chest; break;
        case EquipSlot::LEGS:      target = &equipment.legs;  break;
        case EquipSlot::FEET:      target = &equipment.feet;  break;
        case EquipSlot::NECK:      target = &equipment.neck;  break;
        case EquipSlot::MAIN_HAND:
            target = (ringIndex == 1) ? &equipment.handL : &equipment.handR;
            break;
        case EquipSlot::TWO_HANDS:
            if (equipment.handR) { equipment.handR->revertEquipEffects(this, log); equipment.handR = nullptr; }
            if (equipment.handL) { equipment.handL->revertEquipEffects(this, log); equipment.handL = nullptr; }
            rebuildActions();
            return;
        case EquipSlot::RING:
            if (ringIndex >= 0 && ringIndex < 3) target = &equipment.ring[ringIndex];
            break;
        default: return;
    }

    if (target && *target)
    {
        (*target)->revertEquipEffects(this, log);
        *target = nullptr;
        rebuildActions();
    }
}

void Player::rebuildActions()
{
    // Reconstruit player.actions depuis tous les slots équipés
    actions.clear();

    auto addItemActions = [&](Item* item)
    {
        if (!item) return;
        for (Action* a : item->actions)
            if (a) actions.push_back(*a);
    };

    addItemActions(equipment.head);
    addItemActions(equipment.chest);
    addItemActions(equipment.handR);
    if (equipment.handL != nullptr &&
        equipment.handL != equipment.handR) // évite doublon 2 mains
        addItemActions(equipment.handL);
    addItemActions(equipment.legs);
    addItemActions(equipment.feet);
    addItemActions(equipment.neck);
    for (int i = 0; i < 3; i++) addItemActions(equipment.ring[i]);
}