#pragma once
#include <string>
#include <vector>
#include "action.h"
#include "inventory.h"

// ============================================================
//  CLASSE ENTITY (base de Player et Monster)
//  Classe abstraite — playTurn() est virtuelle pure.
// ============================================================

class Entity
{
public:
    std::string name;
    float       hp;
    float       hpMax;
    float       baseDommage;
    float       baseDefense;
    int         mercy;
    int         mercyGoal;

    std::vector<Action>       actions;
    std::vector<ActiveEffect> activeEffects;
    Inventory                 inventory;

    Entity(const std::string& name, float hp, float hpMax,
           float baseDommage, float baseDefense,
           int mercy = 0, int mercyGoal = 0,
           std::vector<Action> actions = {})
        : name(name), hp(hp), hpMax(hpMax),
          baseDommage(baseDommage), baseDefense(baseDefense),
          mercy(mercy), mercyGoal(mercyGoal),
          actions(actions) {}

    virtual ~Entity() = default;

    // ── Méthode virtuelle pure : Entity est abstraite ────────
    // Player et Monster doivent implémenter leur propre logique de tour.
    virtual void playTurn(Entity* target,
                          std::vector<std::string>* log = nullptr) = 0;

    void tickEffects(std::vector<std::string>* log = nullptr);
};