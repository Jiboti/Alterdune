#pragma once
#include "entity.h"

class Player; // forward declaration — évite le couplage fort

// ============================================================
//  ENUMS
// ============================================================

enum class MonsterCategory
{
    NORMIE,
    MINI_BOSS,
    BOSS
};

enum class MonsterIA
{
    AGGRESSIVE, // choisit l'action avec la valeur la plus haute
    DEFENSIVE,  // préfère les actions selfTarget
    RANDOM      // action aléatoire
};

// ============================================================
//  CLASSE MONSTER
// ============================================================

class Monster : public Entity
{
public:
    int             xpReward;
    int             goldReward;
    MonsterCategory category;
    MonsterIA       ia;
    float           rewardScale = 1.f; // multiplicateur appliqué lors du scaling

    // inventory (hérité d'Entity) = loot pool du monstre

    Monster(const std::string& name, float hp, float hpMax,
            float baseDommage, float baseDefense,
            int mercy, int mercyGoal,
            int xpReward, int goldReward,
            MonsterCategory category, MonsterIA ia,
            std::vector<Action> actions)
        : Entity(name, hp, hpMax, baseDommage, baseDefense,
                 mercy, mercyGoal, actions),
          xpReward(xpReward), goldReward(goldReward),
          category(category), ia(ia) {}

    void playTurn(Entity* target, std::vector<std::string>* log = nullptr) override;
    void giveRewards(Player& player, std::vector<std::string>* log = nullptr);
};