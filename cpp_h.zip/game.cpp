#include "game.h"

#include <fstream>
#include <sstream>
#include <algorithm>
#include <cstdlib>
#include <ctime>
#include <stdexcept>
#include <filesystem>

// ============================================================
//  HELPERS CSV INTERNES
// ============================================================

// Découpe une ligne CSV en tokens (séparateur ';')
// Conserve les tokens vides (ex: trailing ';' → token vide final)
static std::vector<std::string> splitCSV(const std::string& line, char sep = ';')
{
    std::vector<std::string> tokens;
    std::string token;
    for (char c : line)
    {
        if (c == sep) { tokens.push_back(token); token.clear(); }
        else if (c != '\r') token += c; // ignore \r (Windows line endings)
    }
    // Ajoute le dernier token seulement s'il est non vide
    // (évite un token fantôme si la ligne finit par sep)
    if (!token.empty()) tokens.push_back(token);
    return tokens;
}

// Découpe une liste d'ids séparés par '|'   ex: "1|3|7"
static std::vector<int> splitIds(const std::string& s)
{
    std::vector<int> ids;
    std::stringstream ss(s);
    std::string token;
    while (std::getline(ss, token, '|'))
        if (!token.empty()) ids.push_back(std::stoi(token));
    return ids;
}

// Convertit une string en ActionType (format CSV lisible)
static ActionType parseActionType(const std::string& s)
{
    if (s == "DOMMAGE")           return ActionType::DOMMAGE;
    if (s == "HEAL")              return ActionType::HEAL;
    if (s == "BUFF_ATK")          return ActionType::BUFF_ATK;
    if (s == "BUFF_DEF")          return ActionType::BUFF_DEF;
    if (s == "DEBUFF_ATK")        return ActionType::DEBUFF_ATK;
    if (s == "DEBUFF_DEF")        return ActionType::DEBUFF_DEF;
    if (s == "MERCY_DOMMAGE")     return ActionType::MERCY_DOMMAGE;
    if (s == "MERCY_HEAL")        return ActionType::MERCY_HEAL;
    if (s == "DOMMAGE_TIME")      return ActionType::DOMMAGE_TIME;
    if (s == "HEAL_TIME")         return ActionType::HEAL_TIME;
    if (s == "BUFF_ATK_TIME")     return ActionType::BUFF_ATK_TIME;
    if (s == "BUFF_DEF_TIME")     return ActionType::BUFF_DEF_TIME;
    if (s == "DEBUFF_ATK_TIME")   return ActionType::DEBUFF_ATK_TIME;
    if (s == "DEBUFF_DEF_TIME")   return ActionType::DEBUFF_DEF_TIME;
    if (s == "MERCY_DOMMAGE_TIME")return ActionType::MERCY_DOMMAGE_TIME;
    if (s == "MERCY_HEAL_TIME")   return ActionType::MERCY_HEAL_TIME;
    if (s == "CONDITIONAL")       return ActionType::CONDITIONAL;
    return ActionType::DOMMAGE; // fallback
}

// Convertit "TRUE"/"FALSE"/"1"/"0" en bool
static bool parseBool(const std::string& s)
{
    return s == "TRUE" || s == "true" || s == "1";
}

// Convertit une string en MonsterCategory
static MonsterCategory parseCategory(const std::string& s)
{
    if (s == "MINIBOSS" || s == "MINI_BOSS") return MonsterCategory::MINI_BOSS;
    if (s == "BOSS")                         return MonsterCategory::BOSS;
    return MonsterCategory::NORMIE;
}

// Applique un multiplicateur de scaling sur les stats d'un monstre
static void applyScaling(Monster& m, float scale)
{
    m.hp          *= scale;
    m.hpMax       *= scale;
    m.baseDommage *= scale;
    m.rewardScale  = scale; // conservé pour les récompenses
    // La défense ne scale pas — évite des combats trop longs
}

// Convertit une string en EquipSlot
static EquipSlot parseEquipSlot(const std::string& s)
{
    if (s == "HEAD")       return EquipSlot::HEAD;
    if (s == "CHEST")      return EquipSlot::CHEST;
    if (s == "MAIN_HAND")  return EquipSlot::MAIN_HAND;
    if (s == "TWO_HANDS")  return EquipSlot::TWO_HANDS;
    if (s == "LEGS")       return EquipSlot::LEGS;
    if (s == "FEET")       return EquipSlot::FEET;
    if (s == "NECK")       return EquipSlot::NECK;
    if (s == "RING")       return EquipSlot::RING;
    return EquipSlot::NONE;
}

// Convertit une string en MonsterIA
static MonsterIA parseIA(const std::string& s)
{
    if (s == "DEFENSIVE") return MonsterIA::DEFENSIVE;
    if (s == "RANDOM")    return MonsterIA::RANDOM;
    return MonsterIA::AGGRESSIVE;
}

// ── Utilitaires save ──────────────────────────────────────────────────────────

// Parse la valeur après '=' dans une ligne "clé=valeur"
static std::string getVal(const std::string& line)
{
    auto pos = line.find('=');
    return (pos == std::string::npos) ? "" : line.substr(pos + 1);
}

// Crée le dossier Save/ s'il n'existe pas
static void ensureSaveDir()
{
    std::filesystem::create_directories("Save");
}

// ============================================================
//  CHARGEMENT DES DONNÉES CSV/
// ============================================================

bool Game::loadActions(const std::string& path)
{
    std::ifstream file(path);
    if (!file.is_open()) return false;

    std::string line;
    std::getline(file, line); // skip header

    while (std::getline(file, line))
    {
        if (line.empty()) continue;
        auto t = splitCSV(line);
        if (t.size() < 6) continue;

        // id;name;description;type;value;selfTarget
        int         id         = std::stoi(t[0]);
        std::string name       = t[1];
        std::string desc       = t[2];
        ActionType  type       = parseActionType(t[3]);
        float       value      = std::stof(t[4]);
        bool        selfTarget = parseBool(t[5]);

        allActions.emplace_back(id, name, desc, type, value, selfTarget);
    }
    return true;
}

bool Game::loadItems(const std::string& path)
{
    std::ifstream file(path);
    if (!file.is_open()) return false;

    std::string line;
    std::getline(file, line); // skip header

    while (std::getline(file, line))
    {
        if (line.empty()) continue;
        auto t = splitCSV(line);
        if (t.size() < 5) continue;

        // id;name;description;value;type[;actionIds[;iconId]]
        int         id       = std::stoi(t[0]);
        std::string name     = t[1];
        std::string desc     = t[2];
        int         gold     = std::stoi(t[3]);
        ItemType    type     = (t[4] == "EQUIPPABLE" || t[4] == "1")
                               ? ItemType::EQUIPPABLE
                               : ItemType::CONSUMABLE;
        auto      actIds   = (t.size() > 5) ? splitIds(t[5]) : std::vector<int>{};
        // items.csv format: id;name;desc;value;type;actionIds;slotType (plus d'iconId)
        EquipSlot slotType = (t.size() > 6 && !t[6].empty())
                             ? parseEquipSlot(t[6])
                             : EquipSlot::NONE;
        int       iconId   = 0; // iconId retiré

        // Résolution des pointeurs d'actions
        std::vector<Action*> actions;
        for (int aid : actIds)
        {
            auto it = std::find_if(allActions.begin(), allActions.end(),
                [aid](const Action& a) { return a.id == aid; });
            if (it != allActions.end())
                actions.push_back(&(*it));
        }

        allItems.emplace_back(id, name, desc, gold, type, actions, iconId, slotType);
    }
    return true;
}

bool Game::loadMonsters(const std::string& path)
{
    std::ifstream file(path);
    if (!file.is_open()) return false;

    std::string line;
    std::getline(file, line); // skip header

    while (std::getline(file, line))
    {
        if (line.empty()) continue;
        auto t = splitCSV(line);
        if (t.size() < 12) continue;

        // id;name;hp;baseDommage;baseDefense;mercy;mercyGoal;
        // xpReward;goldReward;category;ia;actionIds[;lootIds]
        MonsterEntry e;
        e.id          = std::stoi(t[0]);
        e.name        = t[1];
        e.hp          = std::stof(t[2]);
        e.baseDommage = std::stof(t[3]);
        e.baseDefense = std::stof(t[4]);
        e.mercy       = std::stoi(t[5]);
        e.mercyGoal   = std::stoi(t[6]);
        e.xpReward    = std::stoi(t[7]);
        e.goldReward  = std::stoi(t[8]);
        e.category    = parseCategory(t[9]);
        e.ia          = parseIA(t[10]);
        e.actionIds   = splitIds(t[11]);
        e.lootIds     = (t.size() > 12) ? splitIds(t[12]) : std::vector<int>{};

        allMonsters.push_back(e);
    }
    return true;
}

bool Game::loadRunEntries(const std::string& path)
{
    std::ifstream file(path);
    if (!file.is_open()) return false;

    std::string line;
    std::getline(file, line); // skip header

    while (std::getline(file, line))
    {
        if (line.empty()) continue;
        auto t = splitCSV(line);
        if (t.size() < 3) continue; // hardMonsterIds optionnel

        // combatId;fixedPool;easyMonsterIds;hardMonsterIds
        RunEntry e;
        e.combatId        = std::stoi(t[0]);
        e.fixedPool       = t[1] == "1";
        e.easyMonsterIds  = splitIds(t[2]);
        e.hardMonsterIds  = (t.size() > 3) ? splitIds(t[3]) : std::vector<int>{};

        runEntries.push_back(e);
    }
    return true;
}

bool Game::loadData()
{
    bool ok = true;
    // Chaque CSV est chargé indépendamment pour qu'un échec n'empêche pas les autres
    auto safeLoad = [&](auto fn, const char* path) {
        try { ok &= (this->*fn)(path); }
        catch (...) { /* CSV malformé — on continue */ }
    };
    safeLoad(&Game::loadActions,    "Ressources/CSV/actions.csv");
    safeLoad(&Game::loadItems,      "Ressources/CSV/items.csv");
    safeLoad(&Game::loadMonsters,   "Ressources/CSV/monsters.csv");
    safeLoad(&Game::loadRunEntries, "Ressources/CSV/run.csv");
    return ok;
}

// ============================================================
//  CHARGEMENT / SAUVEGARDE Save/
// ============================================================

bool Game::loadSave()
{
    std::ifstream f("Save/save.txt");
    if (!f.is_open()) return false; // premier lancement = normal

    bool         hasRun     = false;
    std::string  pName;
    int          pClass     = 0;
    float        pHp        = 0, pHpMax = 0, pAtk = 0, pDef = 0;
    int          pLevel     = 1, pXp = 0, pGold = 0;
    int          pNbDead    = 0, pNbSpare = 0, pVictory = 0;
    int          pCombatNum = 0;
    unsigned int pSeed      = 0;
    std::vector<std::pair<int,int>> invSlots;

    std::string line;
    while (std::getline(f, line))
    {
        if (line.empty() || line[0] == '[') continue;
        std::string val = getVal(line);

        // Stats globales
        if      (line.rfind("nbRuns=",        0) == 0) globalStats.nbRuns        = std::stoi(val);
        else if (line.rfind("nbTotalKills=",  0) == 0) globalStats.nbTotalKills  = std::stoi(val);
        else if (line.rfind("nbTotalSpared=", 0) == 0) globalStats.nbTotalSpared = std::stoi(val);
        else if (line.rfind("nbConquete=",    0) == 0) globalStats.nbConquete    = std::stoi(val);
        else if (line.rfind("nbRedemption=",  0) == 0) globalStats.nbRedemption  = std::stoi(val);
        else if (line.rfind("nbEquilibre=",   0) == 0) globalStats.nbEquilibre   = std::stoi(val);
        else if (line.rfind("lastSeed=",      0) == 0) globalStats.lastSeed      = (unsigned int)std::stoul(val);

        // Bestiaire
        else if (line.rfind("bestiary=", 0) == 0)
        {
            auto t = splitCSV(val, ',');
            if (t.size() >= 4)
            {
                BestiaryEntry e;
                e.monsterId  = std::stoi(t[0]);
                e.name       = t[1];
                e.seenKilled = t[2] == "1";
                e.seenSpared = t[3] == "1";
                bestiary.push_back(e);
            }
        }

        // Collection
        else if (line.rfind("collection=", 0) == 0)
        {
            auto t = splitCSV(val, ',');
            if (t.size() >= 3)
            {
                CollectionEntry e;
                e.itemId     = std::stoi(t[0]);
                e.name       = t[1];
                e.discovered = t[2] == "1";
                collection.push_back(e);
            }
        }

        // Historique des runs
        else if (line.rfind("run=", 0) == 0)
        {
            auto t = splitCSV(val, ',');
            if (t.size() >= 9)
            {
                RunRecord r;
                r.runNumber   = std::stoi(t[0]);
                r.ending      = static_cast<RunEnding>(std::stoi(t[1]));
                r.nbKilled    = std::stoi(t[2]);
                r.nbSpared    = std::stoi(t[3]);
                r.level       = std::stoi(t[4]);
                r.gold        = std::stoi(t[5]);
                r.dmgDealt    = std::stoi(t[6]);
                r.turnsPlayed = std::stoi(t[7]);
                r.seed        = (unsigned int)std::stoul(t[8]);
                if ((int)runHistory.size() < MAX_RUN_HISTORY || MAX_RUN_HISTORY == 0)
                    runHistory.push_back(r);
            }
        }

        // Run en cours
        else if (line.rfind("name=",         0) == 0) { pName      = val;                  hasRun = true; }
        else if (line.rfind("powerClass=",   0) == 0)   pClass     = std::stoi(val);
        else if (line.rfind("hp=",           0) == 0)   pHp        = std::stof(val);
        else if (line.rfind("hpMax=",        0) == 0)   pHpMax     = std::stof(val);
        else if (line.rfind("atk=",          0) == 0)   pAtk       = std::stof(val);
        else if (line.rfind("def=",          0) == 0)   pDef       = std::stof(val);
        else if (line.rfind("level=",        0) == 0)   pLevel     = std::stoi(val);
        else if (line.rfind("xp=",           0) == 0)   pXp        = std::stoi(val);
        else if (line.rfind("gold=",         0) == 0)   pGold      = std::stoi(val);
        else if (line.rfind("nbDead=",       0) == 0)   pNbDead    = std::stoi(val);
        else if (line.rfind("nbSpare=",      0) == 0)   pNbSpare   = std::stoi(val);
        else if (line.rfind("victory=",      0) == 0)   pVictory   = std::stoi(val);
        else if (line.rfind("combatNumber=", 0) == 0)   pCombatNum = std::stoi(val);
        else if (line.rfind("seed=",         0) == 0)   pSeed      = (unsigned int)std::stoul(val);
        else if (line.rfind("inv=",          0) == 0)
        {
            auto t = splitCSV(val, ',');
            if (t.size() >= 2)
                invSlots.push_back({std::stoi(t[0]), std::stoi(t[1])});
        }
    }

    // Si le run sauvegardé est invalide (combatNumber hors bornes = run terminé
    // mal nettoyé), on supprime le fichier pour repartir proprement
    if (hasRun && (pCombatNum < 1 || pCombatNum > 10))
        std::filesystem::remove("Save/save.txt");

    // Reconstruction du joueur si un run était en cours
    if (hasRun && !pName.empty() && pCombatNum >= 1 && pCombatNum <= 10)
    {
        PowerClass cls = static_cast<PowerClass>(pClass);

        std::vector<int> powerIds;
        switch (cls) {
            case PowerClass::BERSERKER: powerIds = {0, 6, 7};    break;
            case PowerClass::GUARDIAN:  powerIds = {34, 36, 43}; break;
            case PowerClass::TRICKSTER: powerIds = {28, 29, 22}; break;
        }
        std::vector<Action*> powerActions;
        for (int id : powerIds) {
            auto it = std::find_if(allActions.begin(), allActions.end(),
                [id](const Action& a) { return a.id == id; });
            if (it != allActions.end())
                powerActions.push_back(&(*it));
        }

        currentPlayer.emplace(pName, pHpMax, pHpMax, pAtk, pDef, cls, powerActions);
        Player& p   = currentPlayer.value();
        p.hp        = pHp;
        p.level     = pLevel;
        p.xp        = pXp;
        p.gold      = pGold;
        p.nbKilled  = pNbDead;   // refactor
        p.nbSpared  = pNbSpare;  // refactor
        p.victory   = pVictory;

        combatNumber = pCombatNum;
        seed         = pSeed;
        srand(seed);

        // Restauration inventaire
        for (auto& [itemId, qty] : invSlots)
        {
            auto it = std::find_if(allItems.begin(), allItems.end(),
                [itemId](const Item& i) { return i.id == itemId; });
            if (it != allItems.end())
                p.inventory.add(const_cast<Item*>(&(*it)), qty);
        }

        screen = GameScreen::INTERMEDIATE;
        pathChoices.clear(); // le joueur choisira son chemin sur l'écran intermédiaire
    }

    return hasRun;
}

void Game::saveSave()
{
    ensureSaveDir();

    std::ofstream f("Save/save.txt");
    if (!f.is_open()) return;

    // ── Stats globales ────────────────────────────────────────────────────────
    f << "[GLOBAL]\n";
    f << "nbRuns="        << globalStats.nbRuns        << "\n";
    f << "nbTotalKills="  << globalStats.nbTotalKills  << "\n";
    f << "nbTotalSpared=" << globalStats.nbTotalSpared << "\n";
    f << "nbConquete="    << globalStats.nbConquete    << "\n";
    f << "nbRedemption="  << globalStats.nbRedemption  << "\n";
    f << "nbEquilibre="   << globalStats.nbEquilibre   << "\n";
    f << "lastSeed="      << globalStats.lastSeed      << "\n";

    // ── Bestiaire ─────────────────────────────────────────────────────────────
    f << "[BESTIARY]\n";
    for (const auto& e : bestiary)
        f << "bestiary=" << e.monsterId << ","
          << e.name           << ","
          << (e.seenKilled ? 1 : 0) << ","
          << (e.seenSpared ? 1 : 0) << "\n";

    // ── Collection ────────────────────────────────────────────────────────────
    f << "[COLLECTION]\n";
    for (const auto& e : collection)
        f << "collection=" << e.itemId << ","
          << e.name             << ","
          << (e.discovered ? 1 : 0) << "\n";

    // ── Historique des runs ───────────────────────────────────────────────────
    f << "[HISTORY]\n";
    for (const auto& r : runHistory)
        f << "run=" << r.runNumber   << ","
          << static_cast<int>(r.ending) << ","
          << r.nbKilled   << ","
          << r.nbSpared   << ","
          << r.level      << ","
          << r.gold       << ","
          << r.dmgDealt   << ","
          << r.turnsPlayed << ","
          << r.seed       << "\n";

    // ── Run en cours ──────────────────────────────────────────────────────────
    if (currentPlayer.has_value())
    {
        const Player& p = currentPlayer.value();

        f << "[RUN]\n";
        f << "name="         << p.name                           << "\n";
        f << "powerClass="   << static_cast<int>(p.powerClass)  << "\n";
        f << "hp="           << p.hp                            << "\n";
        f << "hpMax="        << p.hpMax                         << "\n";
        f << "atk="          << p.baseDommage                   << "\n";
        f << "def="          << p.baseDefense                   << "\n";
        f << "level="        << p.level                         << "\n";
        f << "xp="           << p.xp                            << "\n";
        f << "gold="         << p.gold                          << "\n";
        f << "nbDead="       << p.nbKilled                      << "\n";  // refactor
        f << "nbSpare="      << p.nbSpared                      << "\n";  // refactor
        f << "victory="      << p.victory                       << "\n";
        f << "combatNumber=" << combatNumber                    << "\n";
        f << "seed="         << seed                            << "\n";

        for (const auto& slot : p.inventory.slots)
            if (slot.item)
                f << "inv=" << slot.item->id << "," << slot.quantity << "\n";
    }
}

// ============================================================
//  CONSTRUCTION D'UN MONSTER DEPUIS UNE ENTRÉE
// ============================================================

Monster Game::buildMonster(const MonsterEntry& entry) const
{
    // Actions
    std::vector<Action> actions;
    for (int aid : entry.actionIds)
    {
        auto it = std::find_if(allActions.begin(), allActions.end(),
            [aid](const Action& a) { return a.id == aid; });
        if (it != allActions.end())
            actions.push_back(*it);
    }

    // Loot pool → dans l'inventory du monstre
    Monster m(entry.name,
              entry.hp, entry.hp,
              entry.baseDommage, entry.baseDefense,
              entry.mercy, entry.mercyGoal,
              entry.xpReward, entry.goldReward,
              entry.category, entry.ia,
              actions);

    for (int iid : entry.lootIds)
    {
        auto it = std::find_if(allItems.begin(), allItems.end(),
            [iid](const Item& i) { return i.id == iid; });
        if (it != allItems.end())
            m.inventory.add(const_cast<Item*>(&(*it)), 1);
    }

    return m;
}

// ============================================================
//  GESTION DU RUN
// ============================================================

void Game::startRun(unsigned int userSeed)
{
    // Seed
    seed = (userSeed != 0) ? userSeed : (unsigned int)time(nullptr);
    srand(seed);
    globalStats.lastSeed = seed;

    // Reset état run
    combatNumber  = 0;
    combatPhase   = CombatPhase::PLAYER_TURN;
    combatResult  = CombatResult::NONE;
    runEnding     = RunEnding::NONE;
    combatLog.clear();
    pathChoices.clear();
    lootPool.clear();
    shopPool.clear();
    currentMonster.reset();
    resetCombatStats();

    screen = GameScreen::CLASS_SELECT;
}

void Game::startRun(const std::string& playerName, PowerClass powerClass,
                    unsigned int userSeed)
{
    startRun(userSeed);

    // Stats de classe
    float hp = 0.f, dmg = 0.f, def = 0.f;
    switch (powerClass)
    {
        case PowerClass::BERSERKER: hp = 80.f;  dmg = 12.f; def = 3.f;  break;
        case PowerClass::GUARDIAN:  hp = 120.f; dmg = 6.f;  def = 10.f; break;
        case PowerClass::TRICKSTER: hp = 90.f;  dmg = 7.f;  def = 5.f;  break;
    }

    // Résolution des power actions depuis allActions
    // BERSERKER : RAMPAGE(0), BERSERKER_FURY(6), ARMOR_BREAK(7)
    // GUARDIAN  : FORTIFY(34), IRON_SKIN(36), ENDURE(43)
    // TRICKSTER : HEX(28), MIND_LINK(29), ENFEEBLE(22)
    std::vector<int> powerIds;
    switch (powerClass)
    {
        case PowerClass::BERSERKER: powerIds = {0, 6, 7};   break;
        case PowerClass::GUARDIAN:  powerIds = {34, 36, 43}; break;
        case PowerClass::TRICKSTER: powerIds = {28, 29, 22}; break;
    }

    std::vector<Action*> powerActions;
    for (int id : powerIds)
    {
        auto it = std::find_if(allActions.begin(), allActions.end(),
            [id](const Action& a) { return a.id == id; });
        if (it != allActions.end())
            powerActions.push_back(&(*it));
    }

    currentPlayer.emplace(playerName, hp, hp, dmg, def, powerClass, powerActions);
    combatNumber = 1;
    // Prépare les choix du premier combat, mais laisse le joueur choisir
    pathChoices.clear();
    screen = GameScreen::INTERMEDIATE;
}

// ============================================================
//  CONSTRUCTION DU CHEMIN
// ============================================================

void Game::buildPath(bool hardPath)
{
    pathChoices.clear();

    // Récupère l'entrée du run pour ce combat
    auto runIt = std::find_if(runEntries.begin(), runEntries.end(),
        [this](const RunEntry& r) { return r.combatId == combatNumber; });

    if (runIt == runEntries.end()) return;
    const RunEntry& runEntry = *runIt;

    // Helper : construit un pool de MonsterEntry* depuis une liste d'''ids
    auto buildPool = [&](const std::vector<int>& ids) -> std::vector<const MonsterEntry*>
    {
        std::vector<const MonsterEntry*> pool;
        for (int mid : ids)
        {
            auto it = std::find_if(allMonsters.begin(), allMonsters.end(),
                [mid](const MonsterEntry& e) { return e.id == mid; });
            if (it != allMonsters.end()) pool.push_back(&(*it));
        }
        return pool;
    };

    if (runEntry.fixedPool)
    {
        // Combat 1 et 10 : pool unique, 1 monstre tiré aléatoirement
        // Combat 1 : scale 1.0 (pas de scaling), combat 10 : scaling normal
        float scale = 1.f + (combatNumber - 1) * 0.05f;
        auto pool = buildPool(runEntry.easyMonsterIds);
        if (!pool.empty())
        {
            int idx = rand() % (int)pool.size();
            Monster m = buildMonster(*pool[idx]);
            if (combatNumber > 1) applyScaling(m, scale);
            pathChoices.push_back(std::move(m));
        }
    }
    else
    {
        float scaleEasy = 1.f + (combatNumber - 1) * 0.05f;
        float scaleHard = scaleEasy * 1.5f;

        // Chemin facile
        auto poolEasy = buildPool(runEntry.easyMonsterIds);
        if (!poolEasy.empty())
        {
            int idx = rand() % (int)poolEasy.size();
            Monster m = buildMonster(*poolEasy[idx]);
            applyScaling(m, scaleEasy);
            pathChoices.push_back(std::move(m));
        }

        // Chemin difficile
        if (hardPath && !runEntry.hardMonsterIds.empty())
        {
            auto poolHard = buildPool(runEntry.hardMonsterIds);
            if (!poolHard.empty())
            {
                int idx = rand() % (int)poolHard.size();
                Monster m = buildMonster(*poolHard[idx]);
                applyScaling(m, scaleHard);
                pathChoices.push_back(std::move(m));
            }
        }
    }
}

// ============================================================
//  DÉMARRAGE D'UN COMBAT
// ============================================================

void Game::startCombat(int pathIndex)
{
    if (pathIndex < 0 || pathIndex >= (int)pathChoices.size()) return;

    currentMonster.emplace(std::move(pathChoices[pathIndex]));
    pathChoices.clear();

    combatPhase  = CombatPhase::PLAYER_TURN;
    combatResult = CombatResult::NONE;
    combatLog.clear();
    healUsed = false;

    if (currentPlayer.has_value())
    {
        Player& p = currentPlayer.value();
        p.usePower = true;

        // Reset des effets temporaires du joueur entre combats
        // Les buffs/debuffs TIME ont déjà modifié les stats à l'application —
        // on annule les modifications encore actives avant de vider la liste
        for (const auto& eff : p.activeEffects)
        {
            switch (eff.type)
            {
                case ActionType::BUFF_ATK_TIME:   p.baseDommage -= eff.value; break;
                case ActionType::BUFF_DEF_TIME:   p.baseDefense -= eff.value; break;
                case ActionType::DEBUFF_ATK_TIME: p.baseDommage += eff.value; break;
                case ActionType::DEBUFF_DEF_TIME: p.baseDefense += eff.value; break;
                default: break;
            }
        }
        p.activeEffects.clear();

        // Garde les stats dans des bornes valides
        if (p.baseDommage < 0.f) p.baseDommage = 0.f;
        if (p.baseDefense < 0.f) p.baseDefense = 0.f;
    }

    screen = GameScreen::COMBAT;
}

// ============================================================
//  FIN DE TOUR / FIN DE COMBAT
// ============================================================

void Game::checkCombatEnd()
{
    if (!currentPlayer.has_value() || !currentMonster.has_value()) return;

    Player&  player  = currentPlayer.value();
    Monster& monster = currentMonster.value();

    if (player.hp <= 0.f)
    {
        combatResult = CombatResult::DEFEAT;
        combatPhase  = CombatPhase::END;
        combatLog.push_back("!! Vous etes mort...");
        return;
    }
    if (monster.mercy >= monster.mercyGoal)
    {
        combatResult = CombatResult::SPARED;
        combatPhase  = CombatPhase::END;
        combatLog.push_back(">> " + monster.name + " est epargne !");
        return;
    }
    if (monster.hp <= 0.f)
    {
        combatResult = CombatResult::VICTORY;
        combatPhase  = CombatPhase::END;
        combatLog.push_back(">> " + monster.name + " est vaincu !");
        return;
    }
}

// ============================================================
//  RÉCOMPENSES APRÈS COMBAT
// ============================================================

void Game::applyRewards()
{
    if (!currentPlayer.has_value() || !currentMonster.has_value()) return;

    Player&  player  = currentPlayer.value();
    Monster& monster = currentMonster.value();

    bool killed = (combatResult == CombatResult::VICTORY);
    bool spared = (combatResult == CombatResult::SPARED);

    if (killed)
    {
        monster.giveRewards(player, &combatLog);
        player.nbKilled++;
        globalStats.nbTotalKills++;
        combatStats.combatsWon++;
    }
    else if (spared)
    {
        int xp = (int)(monster.xpReward * monster.rewardScale);
        player.gainXP(xp, &combatLog);
        player.nbSpared++;
        globalStats.nbTotalSpared++;
        combatStats.combatsSpared++;
    }

    updateBestiary(
        std::find_if(allMonsters.begin(), allMonsters.end(),
            [&](const MonsterEntry& e) { return e.name == monster.name; })
        != allMonsters.end()
        ? std::find_if(allMonsters.begin(), allMonsters.end(),
            [&](const MonsterEntry& e) { return e.name == monster.name; })->id
        : -1,
        killed
    );

    // Sauvegarde automatique après chaque combat — permet la reprise de run
    saveSave();
}

void Game::buildIntermediateScreen()
{
    lootPool.clear();
    shopPool.clear();

    if (!currentMonster.has_value()) return;
    Monster& monster = currentMonster.value();

    if (!monster.inventory.slots.empty())
    {
        if (monster.category == MonsterCategory::MINI_BOSS ||
            monster.category == MonsterCategory::BOSS)
        {
            // Miniboss / Boss : tous les items du pool sont proposés au choix
            for (auto& slot : monster.inventory.slots)
                if (slot.item) lootPool.push_back(slot.item);
        }
        else
        {
            // Normie : 1 item tiré aléatoirement
            int idx = rand() % (int)monster.inventory.slots.size();
            lootPool.push_back(monster.inventory.slots[idx].item);
        }
        updateCollection(lootPool);
    }

    // Shop : 3 items aléatoires depuis allItems
    if (!allItems.empty())
    {
        std::vector<int> indices;
        for (int i = 0; i < (int)allItems.size(); i++) indices.push_back(i);
        for (int i = 0; i < 3 && !indices.empty(); i++)
        {
            int pick = rand() % (int)indices.size();
            shopPool.push_back(&allItems[indices[pick]]);
            indices.erase(indices.begin() + pick);
        }
    }
}

// ============================================================
//  FIN DE RUN
// ============================================================

RunEnding Game::determineEnding() const
{
    if (!currentPlayer.has_value()) return RunEnding::NONE;
    const Player& player = currentPlayer.value();

    if (player.nbKilled == 0)  return RunEnding::REDEMPTION;
    if (player.nbSpared == 0)  return RunEnding::CONQUETE;
    return RunEnding::EQUILIBRE;
}

void Game::endRun(bool isDeath)
{
    // Sauvegarde des stats du joueur EN PREMIER avant tout reset
    if (currentPlayer.has_value())
    {
        const Player& p       = currentPlayer.value();
        lastRunStats.nbKilled = p.nbKilled;
        lastRunStats.nbSpared = p.nbSpared;
        lastRunStats.level    = p.level;
        lastRunStats.gold     = p.gold;
    }

    // Détermination de la fin
    runEnding = isDeath ? RunEnding::MORT : determineEnding();

    switch (runEnding)
    {
        case RunEnding::CONQUETE:   globalStats.nbConquete++;   break;
        case RunEnding::REDEMPTION: globalStats.nbRedemption++; break;
        case RunEnding::EQUILIBRE:  globalStats.nbEquilibre++;  break;
        default: break;
    }

    // Ajout à l'historique (5 max, plus récent en premier)
    RunRecord record;
    record.runNumber    = globalStats.nbRuns + 1;
    record.ending       = runEnding;
    record.nbKilled     = lastRunStats.nbKilled;
    record.nbSpared     = lastRunStats.nbSpared;
    record.level        = lastRunStats.level;
    record.gold         = lastRunStats.gold;
    record.dmgDealt     = combatStats.dmgDealt;
    record.turnsPlayed  = combatStats.turnsPlayed;
    record.seed         = seed;

    runHistory.insert(runHistory.begin(), record);
    // Pas de limite — tous les runs sont conservés

    globalStats.nbRuns++;

    // Reset du run AVANT saveSave — évite de recharger un run terminé
    currentPlayer.reset();
    currentMonster.reset();
    combatNumber = 0;
    pathChoices.clear();
    lootPool.clear();
    shopPool.clear();

    saveSave();
    screen = GameScreen::END_RUN;
}

// ============================================================
//  PERSISTANCE BESTIAIRE & COLLECTION
// ============================================================

void Game::updateBestiary(int monsterId, bool killed)
{
    if (monsterId < 0) return;

    auto it = std::find_if(bestiary.begin(), bestiary.end(),
        [monsterId](const BestiaryEntry& e) { return e.monsterId == monsterId; });

    if (it != bestiary.end())
    {
        if (killed)  it->seenKilled = true;
        else         it->seenSpared = true;
    }
    else
    {
        // Première rencontre
        auto entryIt = std::find_if(allMonsters.begin(), allMonsters.end(),
            [monsterId](const MonsterEntry& e) { return e.id == monsterId; });
        if (entryIt == allMonsters.end()) return;

        BestiaryEntry e;
        e.monsterId  = monsterId;
        e.name       = entryIt->name;
        e.seenKilled = killed;
        e.seenSpared = !killed;
        bestiary.push_back(e);
    }
}

void Game::updateCollection(const std::vector<Item*>& items)
{
    for (Item* item : items)
    {
        if (!item) continue;
        auto it = std::find_if(collection.begin(), collection.end(),
            [item](const CollectionEntry& e) { return e.itemId == item->id; });

        if (it == collection.end())
        {
            CollectionEntry e;
            e.itemId     = item->id;
            e.name       = item->name;
            e.discovered = true;
            collection.push_back(e);
        }
    }
}

// ============================================================
//  UTILITAIRES
// ============================================================

bool Game::isRunActive() const
{
    return currentPlayer.has_value() && combatNumber > 0;
}

bool Game::isLastCombat() const
{
    return combatNumber == 10;
}