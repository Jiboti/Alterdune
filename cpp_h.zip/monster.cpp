#include <cstdlib>
#include "monster.h"
#include "player.h"

#define LOG(msg) if(log) log->push_back(msg)

void Monster::playTurn(Entity* target, std::vector<std::string>* log)
{
    if (actions.empty()) return;

    int index = 0;

    switch (ia)
    {
        case MonsterIA::AGGRESSIVE:
            for (int i = 1; i < (int)actions.size(); i++)
                if (actions[i].value > actions[index].value) index = i;
            break;

        case MonsterIA::DEFENSIVE:
            for (int i = 0; i < (int)actions.size(); i++)
                if (actions[i].selfTarget) { index = i; break; }
            break;

        case MonsterIA::RANDOM:
            index = rand() % (int)actions.size();
            break;
    }

    Entity* cible = actions[index].selfTarget ? this : target;
    LOG(name + " utilise " + actions[index].name);
    actions[index].apply(cible, log);
}

void Monster::giveRewards(Player& player, std::vector<std::string>* log)
{
    int xp   = (int)(xpReward   * rewardScale);
    int gold = (int)(goldReward * rewardScale);

    player.gainXP(xp, log);
    player.gold += gold;
    LOG("+ " + std::to_string(xp) + " XP  + " + std::to_string(gold) + " Or");
}