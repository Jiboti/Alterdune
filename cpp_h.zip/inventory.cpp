#include "inventory.h"
#include "item.h"
#include "entity.h"

#define LOG(msg) if(log) log->push_back(msg)

void Inventory::add(Item* item, int quantity,
                    std::vector<std::string>* log)
{
    if (!item) return;

    // Si l'item existe déjà, on incrémente la quantité
    for (auto& slot : slots)
    {
        if (slot.item && slot.item->id == item->id)
        {
            slot.quantity += quantity;
            LOG("+" + std::to_string(quantity) + " " + item->name);
            return;
        }
    }

    // Sinon on crée un nouveau slot
    slots.push_back({item, quantity});
    LOG("+" + std::to_string(quantity) + " " + item->name);
}

void Inventory::remove(Item* item, int quantity,
                       std::vector<std::string>* log)
{
    if (!item) return;

    for (auto it = slots.begin(); it != slots.end(); ++it)
    {
        if (it->item && it->item->id == item->id)
        {
            it->quantity -= quantity;
            LOG("-" + std::to_string(quantity) + " " + item->name);
            if (it->quantity <= 0)
                slots.erase(it);
            return;
        }
    }
}

void Inventory::use(int index, Entity* user,
                    std::vector<std::string>* log,
                    Entity* enemy)
{
    if (index < 0 || index >= (int)slots.size()) return;
    InventorySlot& slot = slots[index];
    if (!slot.item) return;

    bool consumed = slot.item->use(user, log, enemy);
    if (consumed)
    {
        slot.quantity--;
        if (slot.quantity <= 0)
            slots.erase(slots.begin() + index);
    }
}