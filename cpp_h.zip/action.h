#pragma once
#include <string>
#include <vector>

class Entity;

// ============================================================
//  ENUMS
// ============================================================

enum class ActionType
{
    // Instantané
    DOMMAGE,
    HEAL,
    BUFF_ATK,
    BUFF_DEF,
    DEBUFF_ATK,
    DEBUFF_DEF,
    MERCY_DOMMAGE,
    MERCY_HEAL,
    // Sur la durée
    DOMMAGE_TIME,
    HEAL_TIME,
    BUFF_ATK_TIME,
    BUFF_DEF_TIME,
    DEBUFF_ATK_TIME,
    DEBUFF_DEF_TIME,
    MERCY_DOMMAGE_TIME,
    MERCY_HEAL_TIME,
    // Logique
    CONDITIONAL
};

enum class StatSelect
{
    NONE,
    HP,
    MERCY,
    BASE_DOMMAGE,
    BASE_DEFENSE
};

// ============================================================
//  STRUCTURES
// ============================================================

struct ActiveEffect
{
    ActionType type;
    float      value;
    int        duration;
};

// ============================================================
//  CLASSE ACTION
// ============================================================

class Action
{
public:
    int         id;
    std::string name;
    std::string description;
    ActionType  type;
    float       value;
    bool        selfTarget;

    // Sous-actions (combo / conditional)
    std::vector<Action*> subActions;

    // Conditional uniquement
    StatSelect statSelect    = StatSelect::NONE;
    float      threshold     = 0.f;
    bool       triggerIfAbove = false;

    // Constructeur standard (subActions optionnel)
    Action(int id, const std::string& name, const std::string& description,
           ActionType type, float value, bool selfTarget,
           std::vector<Action*> subActions = {})
        : id(id), name(name), description(description),
          type(type), value(value), selfTarget(selfTarget),
          subActions(subActions) {}

    // Constructeur conditionnel
    Action(int id, const std::string& name, const std::string& description,
           StatSelect statSelect, float threshold, bool triggerIfAbove,
           std::vector<Action*> subActions)
        : id(id), name(name), description(description),
          type(ActionType::CONDITIONAL), value(0.f), selfTarget(false),
          subActions(subActions), statSelect(statSelect),
          threshold(threshold), triggerIfAbove(triggerIfAbove) {}

    ~Action() = default;

    void apply(Entity* target, std::vector<std::string>* log = nullptr);
};