#pragma once
#include <optional>
#include <memory>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include "ImGui-SFML.h"
#include "imgui.h"
#include "game.h"

// ============================================================
//  CLASSE INTERFACE
//  Responsabilité unique : lire l'état de Game et afficher.
//  Aucune logique de jeu ici — tout changement d'état
//  passe par les méthodes de Game.
// ============================================================

class Interface
{
public:

    // ── Construction / destruction ────────────────────────────
    Interface();
    ~Interface();

    // ── Point d'entrée principal ──────────────────────────────
    void run(Game& game);

private:

    // =========================================================
    //  ASSETS SFML
    // =========================================================

    sf::RenderWindow window;
    sf::Clock        deltaClock;

    // Animation de fond
    std::vector<sf::Texture> bgFrames;
    int   currentFrame  = 0;
    float frameElapsed  = 0.f;
    float frameInterval = 0.1f;

    // Logo (écran de chargement + icône fenêtre)
    sf::Texture logoTexture;
    sf::Sprite  logoSprite;

    // Titre (menu principal)
    sf::Texture titleTexture;
    sf::Sprite  titleSprite;

    // Audio
    sf::Music                  baseMusic;
    sf::SoundBuffer            buttonSoundBuffer;
    std::unique_ptr<sf::Sound> buttonSound; // unique_ptr : sf::Sound n'a pas de constructeur par défaut en SFML 3

    // ── Volume (miroir de game.volumeMusic / volumeFx) ───────
    int sliderVolMusic = 50;
    int sliderVolFx    = 50;

    // ── Sélection de classe ───────────────────────────────────
    int selectedClass = -1;

    // ── Saisie seed ──────────────────────────────────────────
    char seedInput[16] = "";
    char nameInput[32] = "";

    // ── Pause ────────────────────────────────────────────────
    bool paused = false;

    // ── Fondu noir entre scènes ───────────────────────────────
    enum class FadeState { NONE, FADE_OUT, FADE_IN };
    FadeState    fadeState     = FadeState::NONE;
    float        fadeAlpha     = 0.f;
    float        fadeSpeed     = 2.5f; // alpha par seconde
    GameScreen   fadeTarget    = GameScreen::MENU; // écran cible après fondu

    void startFade(GameScreen target); // déclenche un fondu vers target

    // ── Chargement ────────────────────────────────────────────
    bool        dataLoaded     = false;
    std::string loadingMessage = "Chargement...";
    GameScreen  pendingScreen  = GameScreen::MENU; // écran cible après loading



    // =========================================================
    //  INITIALISATION
    // =========================================================

    bool initWindow();
    bool initImGui();
    bool initAssets();

    // =========================================================
    //  BOUCLE PRINCIPALE
    // =========================================================

    void processEvents(Game& game);
    void update(Game& game, float dt);
    void render(Game& game);

    // =========================================================
    //  RENDU PAR ÉCRAN
    // =========================================================

    void renderMenu          (Game& game);
    void renderLoading       (Game& game);
    void renderOptions       (Game& game);
    void renderStatCollection(Game& game);
    void renderClassSelect   (Game& game);
    void renderCombat        (Game& game);
    void renderCombatEnd     (Game& game);
    void renderIntermediate  (Game& game);
    void renderEndRun        (Game& game);
    void renderRingChoice    (Game& game);
    void renderPause         (Game& game); // popup pause en cours de run

    // =========================================================
    //  WIDGETS PARTAGÉS
    // =========================================================

    void        drawBackground();
    void        drawBar(ImDrawList* dl, ImVec2 pos, float width, float height,
                        float value, float maxValue,
                        ImVec4 color, const char* label);
    bool        actionButton(const char* label, ImVec2 size, bool disabled = false,
                             const char* tooltip = nullptr);
    bool        classCard(int classIndex, ImVec2 size, bool selected);
    const char* effectLabel(ActionType type);
    void        drawPanel(ImDrawList* dl, float x, float y, float w, float h,
                          ImVec4 borderColor);
    void        drawSectionTitle(ImDrawList* dl, float panelX, float panelY,
                                 float panelW, const char* title, ImVec4 color);
    bool        beginFullscreen(const char* id);

    // Affiche l'icône d'un item depuis la spritesheet (taille en pixels)
    void drawItemIcon(ImDrawList* dl, int iconId, ImVec2 pos, float size = 32.f);
    void drawEffectBadges(ImDrawList* dl, const std::vector<ActiveEffect>& effects,
                          ImVec2 startPos, float maxWidth);

    // Joue le son bouton si initialisé
    void playButtonSound();
};