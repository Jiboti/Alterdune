#include "game.h"
#include "interface.h"

int main()
{
    Game game;
    game.screen = GameScreen::LOADING;

    // Le chargement réel se fait dans Interface::run()
    // après l'init SFML/ImGui, sur le premier frame LOADING
    Interface iface;
    iface.run(game);

    return 0;
}