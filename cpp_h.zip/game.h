#pragma once
#include <string>
#include <vector>
#include <optional>
#include <ctime>

#include "player.h"
#include "monster.h"
#include "item.h"
#include "action.h"

// ============================================================
//  ENUMS GLOBAUX
// ============================================================

enum class GameScreen
{
    LOADING,
    MENU,
    OPTIONS,
    CLASS_SELECT,
    COMBAT,
    INTERMEDIATE,
    END_RUN,
    STAT_COLLECTION
};

enum class CombatPhase
{
    PLAYER_TURN,
    MONSTER_TURN,
    END
};

enum class CombatResult
{
    NONE,
    VICTORY,
    SPARED,
    DEFEAT
};

enum class RunEnding
{
    NONE,
    CONQUETE,    // 0 épargné
    REDEMPTION,  // 0 tué
    EQUILIBRE,   // mix
    MORT         // défaite
};

// ============================================================
//  STRUCTURES DE DONNÉES CHARGÉES
// ============================================================

// Entrée brute d'un monstre dans le run (avant instanciation)
struct MonsterEntry
{
    int         id;
    std::string name;
    float       hp;
    float       baseDommage;
    float       baseDefense;
    int         mercy;
    int         mercyGoal;
    int         xpReward;
    int         goldReward;
    MonsterCategory category;
    MonsterIA       ia;
    std::vector<int> actionIds; // ids dans allActions
    std::vector<int> lootIds;   // ids dans allItems
};

// Entrée brute du run — pools définis explicitement dans run.csv
struct RunEntry
{
    int  combatId;                   // 1 à 10
    bool fixedPool;                  // true → 1 monstre tiré au hasard (combat 1 et 10)
    std::vector<int> easyMonsterIds; // pool chemin facile
    std::vector<int> hardMonsterIds; // pool chemin difficile (vide si pas de choix)
};

// ============================================================
//  PERSISTANCE INTER-RUN
// ============================================================

struct GlobalStats
{
    int nbRuns        = 0;
    int nbTotalKills  = 0;
    int nbTotalSpared = 0;
    int nbConquete    = 0;
    int nbRedemption  = 0;
    int nbEquilibre   = 0;
    unsigned int lastSeed = 0;
};

struct BestiaryEntry
{
    int         monsterId;
    std::string name;
    bool        seenKilled;
    bool        seenSpared;
};

struct CollectionEntry
{
    int         itemId;
    std::string name;
    bool        discovered;
};

// ============================================================
//  CLASSE GAME
// ============================================================

class Game
{
public:

    // Historique des runs (5 derniers)
    struct RunRecord
    {
        int          runNumber  = 0;
        RunEnding    ending     = RunEnding::NONE;
        int          nbKilled   = 0;
        int          nbSpared   = 0;
        int          level      = 0;
        int          gold       = 0;
        int          dmgDealt   = 0;
        int          turnsPlayed = 0;
        unsigned int seed       = 0;
    };
    static constexpr int MAX_RUN_HISTORY = 0; // 0 = illimité
    std::vector<RunRecord> runHistory;

    // Stats du dernier run terminé (pour l'écran END_RUN)
    struct LastRunStats
    {
        int nbKilled = 0;
        int nbSpared = 0;
        int level    = 0;
        int gold     = 0;
    } lastRunStats;

    // Stats de combat détaillées (accumulées pendant le run)
    struct CombatStats
    {
        int   dmgDealt    = 0; // dégâts infligés
        int   dmgReceived = 0; // dégâts reçus
        int   healReceived = 0; // soins reçus
        int   mercyDealt  = 0; // mercy infligé total
        int   turnsPlayed = 0; // tours joués
        int   combatsWon  = 0;
        int   combatsSpared = 0;
    } combatStats;

    void resetCombatStats()
    {
        combatStats = CombatStats{};
    }

    // ── Navigation ───────────────────────────────────────────
    GameScreen screen = GameScreen::MENU;

    // ── Données chargées depuis CSV/ ─────────────────────────
    std::vector<Action>       allActions;
    std::vector<Item>         allItems;
    std::vector<MonsterEntry> allMonsters;
    std::vector<RunEntry>     runEntries;

    // ── État du run ──────────────────────────────────────────
    std::optional<Player>  currentPlayer;
    std::optional<Monster> currentMonster;

    unsigned int seed        = 0;
    int          combatNumber = 0; // 1 à 10

    CombatPhase  combatPhase  = CombatPhase::PLAYER_TURN;
    CombatResult combatResult = CombatResult::NONE;
    RunEnding    runEnding    = RunEnding::NONE;

    std::vector<std::string> combatLog;

    // Choix de slot bague (quand les 3 sont pleins)
    bool  pendingRingChoice = false;
    Item* pendingRingItem   = nullptr;

    bool  pendingHandChoice = false;
    Item* pendingHandItem   = nullptr;

    int   pendingShopGold   = 0;

    bool  healUsed = false; // soin déjà utilisé cet écran intermédiaire

    // Choix de chemin (2 monstres proposés)
    std::vector<Monster> pathChoices;

    // Loot et shop après combat
    std::vector<Item*> lootPool;
    std::vector<Item*> shopPool;

    // ── Persistance inter-run ─────────────────────────────────
    GlobalStats               globalStats;
    std::vector<BestiaryEntry>  bestiary;
    std::vector<CollectionEntry> collection;

    // ── Interface audio (volume) ──────────────────────────────
    int volumeMusic = 50;
    int volumeFx    = 50;

    // =========================================================
    //  MÉTHODES
    // =========================================================

    // Chargement initial
    bool loadData();   // lit CSV/actions.csv, items.csv, monsters.csv, run.csv
    bool loadSave();   // lit Save/stats.csv, bestiary.csv, collection.csv
    void saveSave();   // écrit Save/

    // Gestion du run
    void startRun(unsigned int userSeed = 0);
    void startRun(const std::string& playerName, PowerClass powerClass,
                  unsigned int userSeed = 0);

    // Construction du chemin
    // hardPath = true → niveau +1 sur le monstre proposé
    void buildPath(bool hardPath);

    // Démarrage d'un combat
    void startCombat(int pathIndex);

    // Fin de tour
    void checkCombatEnd();

    // Après combat (récompenses + mise à jour bestiary/collection)
    void applyRewards();
    void buildIntermediateScreen(); // remplit lootPool et shopPool

    // Fin de run
    RunEnding determineEnding() const;
    void      endRun(bool isDeath = false);

    // Utilitaires
    bool      isRunActive()   const;
    bool      isLastCombat()  const;
    Monster   buildMonster(const MonsterEntry& entry) const;

private:

    // Helpers CSV
    bool loadActions(const std::string& path);
    bool loadItems(const std::string& path);
    bool loadMonsters(const std::string& path);
    bool loadRunEntries(const std::string& path);

    // Mise à jour persistance après combat
    void updateBestiary(int monsterId, bool killed);
    void updateCollection(const std::vector<Item*>& items);
};