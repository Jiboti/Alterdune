#pragma once
#include <vector>
#include <string>
#include "item.h"

class Entity;

// ============================================================
//  STRUCTURE SLOT
// ============================================================

struct InventorySlot
{
    Item* item;
    int   quantity;
};

// ============================================================
//  CLASSE INVENTORY
// ============================================================

class Inventory
{
public:
    std::vector<InventorySlot> slots;

    void add(Item* item, int quantity = 1,
             std::vector<std::string>* log = nullptr);

    void remove(Item* item, int quantity = 1,
                std::vector<std::string>* log = nullptr);

    void use(int index, Entity* user,
             std::vector<std::string>* log = nullptr,
             Entity* enemy = nullptr);
};